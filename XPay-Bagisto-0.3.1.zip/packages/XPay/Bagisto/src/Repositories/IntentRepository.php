<?php

namespace XPay\Bagisto\Repositories;

use Webkul\Core\Eloquent\Repository;
use XPay\Bagisto\Contracts\Intent;

class IntentRepository extends Repository
{
    /** Return the replaceable intent model contract. */
    public function model(): string
    {
        return Intent::class;
    }
}
