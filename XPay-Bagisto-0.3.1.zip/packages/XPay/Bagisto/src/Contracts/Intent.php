<?php

namespace XPay\Bagisto\Contracts;

/** The persisted payment intent contract registered with Concord. */
interface Intent {}
