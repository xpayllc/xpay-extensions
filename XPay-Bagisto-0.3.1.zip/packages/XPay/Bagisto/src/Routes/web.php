<?php

use Illuminate\Support\Facades\Route;
use Webkul\Core\Http\Middleware\PreventRequestsDuringMaintenance;
use XPay\Bagisto\Http\Controllers\CheckoutController;

Route::middleware(['web', 'shop', PreventRequestsDuringMaintenance::class, 'throttle:60,1'])->prefix('xpay')->group(function () {
    Route::get('/checkout/{network}', [CheckoutController::class, 'start'])->name('xpay.start');
    Route::post('/checkout/{network}', [CheckoutController::class, 'checkout'])->name('xpay.checkout');
    Route::match(['GET', 'POST'], '/payment', [CheckoutController::class, 'payment'])->name('xpay.payment');
    Route::post('/cancel', [CheckoutController::class, 'cancel'])->name('xpay.cancel');
    Route::get('/success', [CheckoutController::class, 'success'])->name('xpay.success');
});
