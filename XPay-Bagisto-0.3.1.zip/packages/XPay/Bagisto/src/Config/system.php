<?php

$channel = ['channel_based' => true, 'locale_based' => false, 'depends' => 'active:1'];

return [['key' => 'sales.payment_methods.xpay', 'name' => 'xpay::app.admin.name', 'info' => 'xpay::app.admin.info', 'sort' => 10, 'fields' => [
    ['name' => 'active', 'title' => 'xpay::app.admin.active', 'type' => 'boolean', 'channel_based' => true, 'locale_based' => false],
    array_merge($channel, ['name' => 'title', 'title' => 'xpay::app.admin.title', 'type' => 'text', 'validation' => 'required', 'locale_based' => true]),
    array_merge($channel, ['name' => 'description', 'title' => 'xpay::app.admin.description', 'type' => 'textarea', 'locale_based' => true]),
    array_merge($channel, ['name' => 'test_mode', 'title' => 'xpay::app.admin.test-mode', 'type' => 'boolean', 'info' => 'xpay::app.admin.test-info']),
    array_merge($channel, ['name' => 'recipient', 'title' => 'xpay::app.admin.recipient', 'type' => 'text', 'validation' => 'required|xpay_wallet']),
    array_merge($channel, ['name' => 'api_key', 'title' => 'xpay::app.admin.key', 'type' => 'password', 'validation' => 'xpay_live_key:@sales[payment_methods][xpay][test_mode]']),
    array_merge($channel, ['name' => 'facilitator_url', 'title' => 'xpay::app.admin.endpoint', 'type' => 'text', 'validation' => 'xpay_live_url:@sales[payment_methods][xpay][test_mode]', 'info' => 'xpay::app.admin.endpoint-info']),
    array_merge($channel, ['name' => 'rpc_url', 'title' => 'xpay::app.admin.rpc', 'type' => 'password', 'info' => 'xpay::app.admin.rpc-info', 'validation' => 'xpay_live_url:@sales[payment_methods][xpay][test_mode]']),
    array_merge($channel, ['name' => 'sort', 'title' => 'xpay::app.admin.sort', 'type' => 'number', 'validation' => 'nullable|integer|min:1']),
]]];
