<?php

use XPay\Bagisto\Payment\XPay;

return ['xpay' => ['code' => 'xpay', 'title' => 'XPay USDC · Base', 'description' => 'Pay USDC on Base.', 'class' => XPay::class, 'active' => false, 'sort' => 10]];
