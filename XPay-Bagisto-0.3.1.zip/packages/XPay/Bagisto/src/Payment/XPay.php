<?php

namespace XPay\Bagisto\Payment;

use Webkul\Payment\Payment\Payment;
use XPay\Bagisto\Services\Networks;
use XPay\Bagisto\Services\Settings;

class XPay extends Payment
{
    /**
     * @var string
     */
    protected $code = 'xpay';

    /**
     * @var string
     */
    protected $network = Networks::BASE;

    /**
     * Expose the payment method only on a supported and configured checkout.
     */
    public function isAvailable()
    {
        if (
            PHP_INT_SIZE < 8
            || ! parent::isAvailable()
            || ! request()->isSecure()
        ) {
            return false;
        }
        $cart = $this->getCart();
        if (
            ! $cart
            || $cart->cart_currency_code !== 'USD'
            || $cart->base_currency_code !== 'USD'
            || core()->getCurrentChannel()->base_currency->code !== 'USD'
        ) {
            return false;
        }
        try {
            Settings::validate($cart->channel?->code);
        } catch (\Throwable) {
            return false;
        }

        return true;
    }

    /**
     * Return the read-only entry page for the selected checkout network.
     */
    public function getRedirectUrl()
    {
        session()->put('xpay.cart_id', $this->getCart()?->id);
        session()->put('xpay.network', $this->network);

        return route('xpay.start', ['network' => 'base']);
    }

    /**
     * Return the locally published official XPay logo.
     */
    public function getImage()
    {
        return asset('vendor/xpay/logo.svg');
    }
}
