<?php

namespace XPay\Bagisto\Console;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use XPay\Bagisto\Models\Intent;
use XPay\Bagisto\Services\Audit;
use XPay\Bagisto\Services\Gateway;
use XPay\Bagisto\Services\OrderLock;
use XPay\Bagisto\Services\Payments;
use XPay\Bagisto\Services\Rules;

final class Reconcile extends Command
{
    /**
     * @var string
     */
    protected $signature = 'xpay:reconcile {intent : Local XPay intent ID} {hash : Known settlement transaction hash}';

    /**
     * @var string
     */
    protected $description = 'Verify a known payment receipt and reconcile its existing order without broadcasting a transaction';

    /**
     * Reconcile stored payment evidence without requesting another authorization.
     */
    public function handle(Gateway $gateway, Payments $payments): int
    {
        $id = (int) $this->argument('intent');
        $hash = strtolower((string) $this->argument('hash'));
        if (! preg_match('/^0x[a-f0-9]{64}$/D', $hash)) {
            $this->error('Invalid transaction hash.');

            return self::FAILURE;
        }
        try {
            $intent = Intent::findOrFail($id);
            OrderLock::run('cart:'.$intent->cart_id, function () use ($intent, $gateway, $hash) {
                $intent->refresh();
                $network = $intent->quote['terms']['network'];
                if (! $intent->authorization) {
                    throw new \RuntimeException('No persisted order authorization exists.');
                }
                if (
                    $intent->transaction_hash
                    && strtolower($intent->transaction_hash) !== $hash
                ) {
                    throw new \RuntimeException('Conflicting transaction already recorded.');
                }
                $receipt = $gateway->receipt($hash, $network, $intent->channel_code);
                if (! $receipt) {
                    throw new \RuntimeException('Receipt is not available.');
                }
                $transaction = $network === 'eip155:56' ? $gateway->transaction($hash, $network) : null;
                Rules::receipt($receipt, $intent->quote, Rules::payer($intent->authorization, $network), $hash, $transaction, $intent->authorization);
                $intent->transaction_hash = $hash;
                $intent->payment_reference = $hash;
                $intent->status = 'submitted';
                $intent->save();
            });
            $result = $payments->process($intent, null);
            if (empty($result['paid'])) {
                $this->warn('Payment remains pending; order was not fulfilled.');

                return self::FAILURE;
            }
            $this->info('Payment verified and order reconciled. No transaction was broadcast by this command.');

            return self::SUCCESS;
        } catch (\Throwable $e) {
            if (isset($intent)) {
                Audit::failure('manual-reconciliation', $intent, $e);
            } else {
                Log::warning('XPay reconciliation intent unavailable', ['intent_id' => $id, 'exception_class' => get_class($e)]);
            }
            $this->error(__('xpay::app.console.reconcile-failed'));

            return self::FAILURE;
        }
    }
}
