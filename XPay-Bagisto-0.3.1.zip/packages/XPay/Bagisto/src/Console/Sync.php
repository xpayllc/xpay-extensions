<?php

namespace XPay\Bagisto\Console;

use Illuminate\Console\Command;
use Webkul\Checkout\Models\Cart;
use Webkul\Sales\Models\Order;
use Webkul\Sales\Repositories\OrderRepository;
use XPay\Bagisto\Models\Intent;
use XPay\Bagisto\Services\Audit;
use XPay\Bagisto\Services\OrderLock;
use XPay\Bagisto\Services\Payments;

final class Sync extends Command
{
    /**
     * @var string
     */
    protected $signature = 'xpay:sync {--limit=100}';

    /**
     * @var string
     */
    protected $description = 'Reconcile persisted XPay payments and expire unsigned checkout intents';

    /**
     * Reconcile stored payment evidence without requesting another authorization.
     */
    public function handle(Payments $payments, OrderRepository $orders): int
    {
        $failed = 0;
        $deadline = microtime(true) + 45;
        Intent::whereIn('status', ['pending', 'submitted', 'verified'])->orderBy('updated_at')->orderBy('id')->limit(max(1, min(1000, (int) $this->option('limit'))))->get()->each(function ($intent) use ($payments, $orders, &$failed, $deadline) {
            if (microtime(true) > $deadline) {
                return false;
            }
            try {
                if (
                    $intent->mode === 'live'
                    && $intent->authorization
                ) {
                    $payments->process($intent, null);
                } elseif (! $intent->authorization && ! $intent->transaction_hash && ! $intent->payment_reference && $intent->quote['expires'] < time()) {
                    OrderLock::run('cart:'.$intent->cart_id, function () use ($intent, $orders) {
                        $intent->refresh();
                        if (
                            $intent->authorization
                            || $intent->transaction_hash
                            || $intent->payment_reference
                            || $intent->status === 'paid'
                        ) {
                            return;
                        }
                        if ($intent->order_id) {
                            $order = $orders->find($intent->order_id);
                            if (
                                $order
                                && $order->status !== Order::STATUS_CANCELED
                                && ! $orders->cancel($order, true)
                            ) {
                                throw new \RuntimeException('Legacy order cancellation failed.');
                            }
                        }
                        $intent->status = 'expired';
                        $intent->save();
                        if (! $intent->order_id) {
                            Cart::whereKey($intent->cart_id)->update(['is_active' => 1]);
                        }
                    });
                }
            } catch (\Throwable $e) {
                $failed++;
                Audit::failure('scheduled-reconciliation', $intent, $e);
            } finally {
                $intent->touch();
            }
        });
        $this->info(__('xpay::app.console.sync', ['count' => $failed]));

        return $failed ? self::FAILURE : self::SUCCESS;
    }
}
