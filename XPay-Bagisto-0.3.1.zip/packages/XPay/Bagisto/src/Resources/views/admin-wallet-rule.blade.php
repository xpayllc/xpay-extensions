<script>
window.addEventListener('load', function () {
    const simulated = function (params) {
        return document.getElementById('sales[payment_methods][xpay][test_mode]')?.checked === true;
    };
    window.defineRule('xpay_live_key', function (value, params) {
        return simulated(params)
            || (typeof value === 'string' && value.trim().length > 0 && value.length <= 512)
            || @json(__('xpay::app.errors.configuration'));
    });
    window.defineRule('xpay_live_url', function (value, params) {
        if (simulated(params)) return true;
        try {
            const url = new URL(value);
            return (url.protocol === 'https:' && !url.username && !url.password && !url.hash)
                || @json(__('xpay::app.errors.configuration'));
        } catch (_) {
            return @json(__('xpay::app.errors.configuration'));
        }
    });
    window.defineRule('xpay_wallet', function (value) {
        return !value || /^0x[a-fA-F0-9]{40}$/.test(value)
            || @json(__('xpay::app.errors.wallet'));
    });
});
</script>
