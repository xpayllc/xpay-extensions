(() => {
'use strict';
const cfg=window.XPayCheckout, pay=document.getElementById('xpay-connect'),retry=document.getElementById('xpay-recheck'),status=document.getElementById('xpay-status'),amount=document.getElementById('xpay-amount'),m=cfg.messages;
let submitted=false,busy=false;
const display=a=>{const n=BigInt(a),f=(n%1000000n).toString().padStart(6,'0').replace(/0+$/,'');return (n/1000000n).toLocaleString()+(f?'.'+f:'')+' USDC';};
async function call(method,payload){const r=await fetch(cfg.url,{method,credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json','Content-Type':'application/json','X-CSRF-TOKEN':cfg.csrf},...(method==='POST'?{body:JSON.stringify(payload?{paymentPayload:payload}:{})}:{})});let d;try{d=await r.json();}catch{throw Error(m.connection);}if(![200,202,402].includes(r.status))throw Error(d.error||m.connection);return {r,d};}
function done(d){if(d.paid){status.textContent=m.confirmed;window.location.assign(cfg.success);return true;}return false;}
function terms(d){const t=d.accepts?.[0],q=d.extensions?.['xpay-order'];if(d.x402Version!==2||d.accepts?.length!==1||t.network!=='eip155:8453'||t.network!==cfg.network||t.asset?.toLowerCase()!=='0x833589fcd6edb6e08f4c7c32d4f71b54bda02913'||!/^\d+$/.test(t.amount)||BigInt(t.amount)<=0n||!/^0x[0-9a-f]{40}$/i.test(t.payTo)||!/^0x[0-9a-f]{64}$/i.test(q?.nonce)||!Number.isSafeInteger(q.expires))throw Error(m.unsupported);return {t,q};}
async function run(reconcile){if(busy)return;busy=true;pay.disabled=true;retry.disabled=true;try{
 let {r,d}=await call('GET');if(done(d))return;
 if(d.pending||submitted){submitted=true;retry.hidden=false;if(reconcile){({d}=await call('POST'));if(done(d))return;}status.textContent=d.requiresMerchantReview?m.merchant:m.pending;return;}
 if(reconcile)return;
 if(cfg.sandbox){if(!d.sandbox)throw Error(m.unsupported);status.textContent=m.sandbox;({d}=await call('POST',{sandbox:true}));done(d);return;}
 const {t,q}=terms(d);amount.textContent=display(t.amount);
 const wallet=window.ethereum;if(!wallet)throw Error(m.wallet);
 const [from]=await wallet.request({method:'eth_requestAccounts'});await wallet.request({method:'wallet_switchEthereumChain',params:[{chainId:'0x2105'}]});
 if(q.expires<=Math.floor(Date.now()/1000)+5)throw Error(m.expired);
 const authorization={from,to:t.payTo,value:t.amount,validAfter:'0',validBefore:String(q.expires),nonce:q.nonce};
 const typed={domain:{name:'USD Coin',version:'2',chainId:8453,verifyingContract:t.asset},primaryType:'TransferWithAuthorization',types:{EIP712Domain:[{name:'name',type:'string'},{name:'version',type:'string'},{name:'chainId',type:'uint256'},{name:'verifyingContract',type:'address'}],TransferWithAuthorization:[{name:'from',type:'address'},{name:'to',type:'address'},{name:'value',type:'uint256'},{name:'validAfter',type:'uint256'},{name:'validBefore',type:'uint256'},{name:'nonce',type:'bytes32'}]},message:authorization};
 status.textContent=m.review;const signature=await wallet.request({method:'eth_signTypedData_v4',params:[from,JSON.stringify(typed)]});
 submitted=true;retry.hidden=false;status.textContent=m.submitting;
 ({d}=await call('POST',{x402Version:2,resource:d.resource,accepted:t,payload:{signature,authorization}}));if(!done(d))status.textContent=m.pending;
 }catch(e){status.textContent=e.code===4001?m.canceled:(submitted?m.connection:e.message);}finally{busy=false;pay.disabled=submitted;retry.disabled=false;}}
pay.addEventListener('click',()=>run(false));retry.addEventListener('click',()=>run(true));
call('GET').then(({d})=>{if(done(d))return;if(d.pending){submitted=true;pay.disabled=true;retry.hidden=false;status.textContent=m.pending;}else if(cfg.sandbox&&d.sandbox){amount.textContent=display(d.amount);status.textContent=m.sandbox;}else{const {t}=terms(d);amount.textContent=display(t.amount);}}).catch(e=>{status.textContent=e.message;pay.disabled=true;});
})();
