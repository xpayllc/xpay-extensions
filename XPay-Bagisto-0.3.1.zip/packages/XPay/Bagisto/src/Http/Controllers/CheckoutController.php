<?php

namespace XPay\Bagisto\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Webkul\Checkout\Facades\Cart;
use Webkul\Sales\Repositories\OrderRepository;
use Webkul\Sales\Transformers\OrderResource;
use XPay\Bagisto\Models\Intent;
use XPay\Bagisto\Repositories\IntentRepository;
use XPay\Bagisto\Services\Audit;
use XPay\Bagisto\Services\CheckoutValidation;
use XPay\Bagisto\Services\Networks;
use XPay\Bagisto\Services\OrderLock;
use XPay\Bagisto\Services\Payments;
use XPay\Bagisto\Services\Rules;
use XPay\Bagisto\Services\Settings;
use XPay\Bagisto\Services\Snapshots;

class CheckoutController extends Controller
{
    /**
     * Render the checkout entry form without changing cart or payment state.
     */
    public function start(Request $r)
    {
        abort_unless($r->isSecure(), 403);
        abort_unless($r->route('network') === 'base', 404);
        abort_unless(session('xpay.network') === Networks::BASE, 403);

        return response()->view('xpay::start')->header('Cache-Control', 'no-store');
    }

    /**
     * Create a persisted checkout only for an authenticated, CSRF-protected POST.
     */
    public function checkout(Request $r, OrderRepository $orders, IntentRepository $intents)
    {
        abort_unless($r->isSecure(), 403);
        if ($r->isMethod('HEAD')) {
            return response('', 204);
        }
        abort_unless($r->route('network') === 'base', 404);
        abort_unless(session('xpay.network') === Networks::BASE, 403);
        if ($id = session('xpay.intent_id')) {
            $current = Intent::find($id);
            if (
                $current
                && ! in_array($current->status, ['canceled', 'expired'], true)
                && (! Cart::getCart()
                || (int) Cart::getCart()->id === (int) $current->cart_id)
            ) {
                return $this->page($current);
            }
        }
        $cart = Cart::getCart();
        abort_unless($cart && (int) session('xpay.cart_id') === (int) $cart->id, 403);
        abort_if(Cart::requiresSignInToCheckout() || Cart::hasError(), 422);
        Cart::collectTotals();
        app(CheckoutValidation::class)->validate($cart);
        $cart = Cart::getCart();
        abort_unless($cart->payment?->method === 'xpay' && $cart->cart_currency_code === 'USD' && $cart->base_currency_code === 'USD' && core()->getCurrentChannel()->base_currency->code === 'USD', 422, __('xpay::app.errors.currency'));
        $channel = $cart->channel?->code ?: core()->getCurrentChannelCode();
        Settings::validate($channel);
        $q = Rules::quote((string) $cart->grand_total, (string) Settings::get('recipient', $channel), time());
        $token = bin2hex(random_bytes(32));
        $intent = OrderLock::run('cart:'.$cart->id, function () use ($cart, $orders, $q, $token, $channel, $intents) {
            abort_if(Intent::where('cart_id', $cart->id)->whereNotIn('status', ['canceled', 'expired'])->exists() || $orders->findOneWhere(['cart_id' => $cart->id]), 409, __('xpay::app.errors.resume'));

            return $intents->create(['cart_id' => $cart->id, 'channel_code' => $channel, 'mode' => Settings::sandbox($channel) ? 'sandbox' : 'live', 'order_data' => (new OrderResource($cart))->jsonSerialize(), 'token_hash' => hash('sha256', $token), 'quote' => $q]);
        });
        session()->put('xpay.intent_id', $intent->id);
        session()->put('xpay.token', $token);
        app(Snapshots::class)->read($intent->fresh());

        return $this->page($intent);
    }

    /**
     * Resolve and authenticate the checkout intent owned by this session.
     */
    private function intent(Request $r): Intent
    {
        abort_unless($r->isSecure(), 403);
        $intent = Intent::findOrFail(session('xpay.intent_id'));
        abort_unless($intent->quote['terms']['network'] === Networks::BASE, 404);
        $token = $r->header('X-XPay-Order-Key') ?: session('xpay.token');
        abort_unless(is_string($token) && hash_equals($intent->token_hash, hash('sha256', $token)), 403);

        return $intent;
    }

    /**
     * Render the wallet checkout after validating the stored snapshot.
     */
    private function page(Intent $intent)
    {
        if (! $intent->order_id) {
            app(Snapshots::class)->read($intent);
        }

        return response()->view('xpay::checkout', ['settings' => ['url' => route('xpay.payment'), 'csrf' => csrf_token(), 'success' => route('xpay.success'), 'cancel' => route('xpay.cancel'), 'network' => Networks::BASE, 'sandbox' => $intent->mode === 'sandbox', 'messages' => __('xpay::app.js')]])->header('Cache-Control', 'no-store')->header('Referrer-Policy', 'no-referrer');
    }

    /**
     * Return payment terms or process the same authorized payment.
     */
    public function payment(Request $r, Payments $payments)
    {
        $intent = $this->intent($r);
        if ($intent->status === 'paid') {
            return $this->result(['paid' => true, 'transaction' => $intent->payment_reference ?: $intent->transaction_hash]);
        }
        if (in_array($intent->status, ['canceled', 'expired'], true)) {
            return response()->json(['error' => __('xpay::app.errors.expired')], 410)->header('Cache-Control', 'no-store');
        }
        if (! $r->isMethod('POST')) {
            if (
                $intent->authorization
                || $intent->status === 'verified'
            ) {
                return $this->result(['paid' => false, 'pending' => true]);
            }
            if ($intent->quote['expires'] <= time()) {
                return response()->json(['error' => __('xpay::app.errors.expired')], 410)->header('Cache-Control', 'no-store');
            }
            if ($intent->mode === 'sandbox') {
                return response()->json(['sandbox' => true, 'amount' => $intent->quote['terms']['amount']], 200)->header('Cache-Control', 'no-store');
            }
            $body = ['x402Version' => 2, 'resource' => ['url' => route('xpay.payment'), 'description' => __('xpay::app.checkout.resource', ['id' => $intent->id]), 'mimeType' => 'application/json'], 'accepts' => [$intent->quote['terms']], 'extensions' => ['xpay-order' => ['nonce' => $intent->quote['nonce'], 'expires' => $intent->quote['expires']]]];

            return response()->json($body, 402)->header('PAYMENT-REQUIRED', base64_encode(json_encode($body)))->header('Cache-Control', 'no-store');
        }
        abort_if(strlen($r->getContent()) > 16384, 413);
        $payload = $r->input('paymentPayload');
        if ($raw = $r->header('PAYMENT-SIGNATURE')) {
            $payload = json_decode(base64_decode($raw, true) ?: '', true);
        }
        abort_if($payload !== null && ! is_array($payload), 422);
        try {
            return $this->result($payments->process($intent, $payload));
        } catch (\Throwable $e) {
            Audit::failure('checkout', $intent, $e);

            return response()->json(['paid' => false, 'error' => __('xpay::app.errors.confirm')], 422)->header('Cache-Control', 'no-store');
        }
    }

    /**
     * Format confirmed or pending payment evidence without requesting a second payment.
     */
    private function result(array $result)
    {
        $result['redirect'] = ! empty($result['paid']) ? route('xpay.success') : null;

        return response()->json($result, ! empty($result['paid']) ? 200 : 202)->header('Cache-Control', 'no-store')->header('PAYMENT-RESPONSE', base64_encode(json_encode(['success' => ! empty($result['paid']), 'network' => Networks::BASE, 'transaction' => $result['transaction'] ?? null])));
    }

    /**
     * Cancel an unsigned intent and restore its cart under the payment lock.
     */
    public function cancel(Request $r)
    {
        $intent = $this->intent($r);
        OrderLock::run('cart:'.$intent->cart_id, function () use ($intent) {
            $intent->refresh();
            abort_if($intent->authorization || $intent->transaction_hash || $intent->order_id || $intent->payment_reference, 409, __('xpay::app.errors.pending-cancel'));
            $intent->status = 'canceled';
            $intent->save();
            Cart::activateCart($intent->cart_id);
        });
        session()->forget(['xpay.intent_id', 'xpay.token', 'xpay.cart_id', 'xpay.network']);

        return redirect()->route('shop.checkout.cart.index');
    }

    /**
     * Redirect a confirmed payment to the Bagisto order confirmation.
     */
    public function success(Request $r)
    {
        $intent = $this->intent($r);
        abort_unless($intent->status === 'paid' && $intent->order_id, 409);
        session()->flash('order_id', $intent->order_id);

        return redirect()->route('shop.checkout.onepage.success');
    }
}
