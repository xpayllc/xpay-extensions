<?php

namespace XPay\Bagisto\Models;

use Konekt\Concord\Proxies\ModelProxy;

/** Resolve the intent model registered with Concord. */
class IntentProxy extends ModelProxy {}
