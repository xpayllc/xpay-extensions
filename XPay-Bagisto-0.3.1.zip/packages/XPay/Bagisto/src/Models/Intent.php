<?php

namespace XPay\Bagisto\Models;

use Illuminate\Database\Eloquent\Model;

class Intent extends Model implements \XPay\Bagisto\Contracts\Intent
{
    /**
     * @var string
     */
    protected $table = 'xpay_intents';

    /**
     * @var array<int, string>
     */
    protected $guarded = ['id'];

    /**
     * @var array<int, string>
     */
    protected $hidden = ['token_hash', 'authorization', 'order_data'];

    /**
     * @var array<string, string>
     */
    protected $casts = ['quote' => 'array', 'authorization' => 'encrypted:array', 'order_data' => 'encrypted:array'];
}
