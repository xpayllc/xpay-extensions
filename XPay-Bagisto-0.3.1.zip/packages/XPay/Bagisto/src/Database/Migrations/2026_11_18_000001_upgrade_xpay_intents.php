<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('xpay_intents', function (Blueprint $t) {
            $t->dropUnique('xpay_intents_cart_id_unique');
            $t->unsignedInteger('order_id')->nullable()->change();
            $t->foreign('order_id')->references('id')->on('orders')->restrictOnDelete();
            $t->index('cart_id');
            $t->string('channel_code')->nullable();
            $t->string('mode')->default('live');
            $t->text('order_data')->nullable();
            $t->string('payment_reference', 96)->nullable()->unique();
        });
    }

    public function down(): void
    {
        // Do not discard payment evidence or restore a non-null order constraint over unpaid intents.
        throw new RuntimeException('Restore the pre-upgrade database backup to roll back XPay 0.3.0.');
    }
};
