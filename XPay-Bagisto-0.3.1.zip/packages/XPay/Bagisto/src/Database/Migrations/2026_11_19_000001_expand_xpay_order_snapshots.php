<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Expand encrypted snapshots without truncating existing payment evidence. */
    public function up(): void
    {
        Schema::table('xpay_intents', function (Blueprint $table) {
            $table->longText('order_data')->nullable()->change();
        });
    }

    /** Never truncate snapshots when rolling back. */
    public function down(): void
    {
        throw new RuntimeException('Restore a backup to roll back XPay 0.3.1; snapshots must not be truncated.');
    }
};
