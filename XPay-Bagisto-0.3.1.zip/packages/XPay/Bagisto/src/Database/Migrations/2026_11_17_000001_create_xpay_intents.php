<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('xpay_intents', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('order_id')->unique();
            $t->unsignedBigInteger('cart_id')->unique();
            $t->string('token_hash', 64);
            $t->json('quote');
            $t->text('authorization')->nullable();
            $t->string('transaction_hash', 66)->nullable()->unique();
            $t->string('status')->default('pending');
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('xpay_intents');
    }
};
