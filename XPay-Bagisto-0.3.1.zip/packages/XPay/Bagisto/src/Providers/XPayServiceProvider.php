<?php

namespace XPay\Bagisto\Providers;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\ServiceProvider;
use XPay\Bagisto\Console\Reconcile;
use XPay\Bagisto\Console\Sync;

class XPayServiceProvider extends ServiceProvider
{
    /**
     * Register the extension configuration with the host application.
     */
    public function register(): void
    {
        $this->app->register(ModuleServiceProvider::class);
        $this->mergeConfigFrom(__DIR__.'/../Config/payment-methods.php', 'payment_methods');
        $this->mergeConfigFrom(__DIR__.'/../Config/system.php', 'core');
        $this->mergeConfigFrom(__DIR__.'/../Config/xpay.php', 'xpay');
    }

    /**
     * Register the extension services, validation, scheduler, routes and resources.
     */
    public function boot(): void
    {
        $this->loadTranslationsFrom(__DIR__.'/../Resources/lang', 'xpay');
        Validator::extend('xpay_wallet', static function ($attribute, $value) {
            return is_string($value) && preg_match('/^0x[a-fA-F0-9]{40}$/D', $value) === 1;
        }, __('xpay::app.errors.wallet'));
        Validator::extendImplicit('xpay_live_key', static function ($attribute, $value, $parameters, $validator) {
            if ((string) data_get($validator->getData(), 'sales.payment_methods.xpay.test_mode') === '1') {
                return true;
            }

            return is_string($value) && trim($value) !== '' && strlen($value) <= 512;
        }, __('xpay::app.errors.configuration'));
        Validator::extendImplicit('xpay_live_url', static function ($attribute, $value, $parameters, $validator) {
            if ((string) data_get($validator->getData(), 'sales.payment_methods.xpay.test_mode') === '1') {
                return true;
            }

            return is_string($value)
                && filter_var($value, FILTER_VALIDATE_URL) !== false
                && parse_url($value, PHP_URL_SCHEME) === 'https'
                && parse_url($value, PHP_URL_USER) === null
                && parse_url($value, PHP_URL_FRAGMENT) === null;
        }, __('xpay::app.errors.configuration'));
        Event::listen('bagisto.admin.layout.vue-app-mount.before', function ($view) {
            $view->addTemplate('xpay::admin-wallet-rule');
        });
        if ($this->app->runningInConsole()) {
            $this->commands([Reconcile::class, Sync::class]);
            $this->app->afterResolving(Schedule::class, function (Schedule $schedule) {
                $schedule->command('xpay:sync')->everyMinute()->withoutOverlapping(10);
            });
        }
        $this->loadRoutesFrom(__DIR__.'/../Routes/web.php');
        $this->loadViewsFrom(__DIR__.'/../Resources/views', 'xpay');
        $this->loadMigrationsFrom(__DIR__.'/../Database/Migrations');
        $this->publishes([__DIR__.'/../Resources/assets' => public_path('vendor/xpay')], 'xpay-assets');
    }
}
