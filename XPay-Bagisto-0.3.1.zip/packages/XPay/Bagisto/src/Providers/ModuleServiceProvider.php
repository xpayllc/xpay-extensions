<?php

namespace XPay\Bagisto\Providers;

use Webkul\Core\Providers\CoreModuleServiceProvider;
use XPay\Bagisto\Models\Intent;

class ModuleServiceProvider extends CoreModuleServiceProvider
{
    /**
     * The extension models registered with Concord.
     *
     * @var array
     */
    protected $models = [
        Intent::class,
    ];
}
