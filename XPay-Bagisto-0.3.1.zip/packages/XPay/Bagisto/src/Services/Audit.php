<?php

namespace XPay\Bagisto\Services;

use Illuminate\Support\Facades\Log;
use XPay\Bagisto\Models\Intent;

final class Audit
{
    /**
     * Record operational identifiers while excluding secrets and authorization payloads.
     */
    public static function failure(string $stage, Intent $intent, \Throwable $e): void
    {

        Log::warning('XPay payment operation delayed', ['stage' => $stage, 'intent_id' => $intent->id, 'order_id' => $intent->order_id, 'exception_class' => get_class($e)]);
    }
}
