<?php

namespace XPay\Bagisto\Services;

use RuntimeException;
use Webkul\Checkout\Facades\Cart;
use Webkul\Checkout\Models\Cart as CartModel;
use Webkul\Sales\Transformers\OrderResource;
use XPay\Bagisto\Models\Intent;

final class Snapshots
{
    /** Read the persisted encrypted value back from the database before exposing payment. */
    public function read(Intent $intent): array
    {
        $data = $intent->fresh()->order_data;
        if (
            ! is_array($data)
            || ($data['order_currency_code'] ?? '') !== 'USD'
            || ($data['base_currency_code'] ?? '') !== 'USD'
            || Rules::amount((string) ($data['grand_total'] ?? '')) !== $intent->quote['terms']['amount']
        ) {
            throw new RuntimeException(__('xpay::app.errors.order'));
        }

        return $data;
    }

    /** Re-check inventory, current coupon eligibility and unchanged checkout details before settlement. */
    public function validateBeforePayment(Intent $intent): void
    {
        $snapshot = $this->read($intent);
        $cart = CartModel::findOrFail($intent->cart_id);
        Cart::setCart($cart);
        if (
            ! Cart::validateItems()
            || Cart::hasError()
        ) {
            throw new RuntimeException(__('xpay::app.errors.order'));
        }
        Cart::collectTotals();
        $cart = Cart::getCart();
        app(CheckoutValidation::class)->validate($cart);
        $current = (new OrderResource($cart))->jsonSerialize();
        if (
            $current != $snapshot
            || $cart->channel?->code !== $intent->channel_code
            || strtolower((string) Settings::get('recipient', $intent->channel_code)) !== strtolower($intent->quote['terms']['payTo'])
        ) {
            throw new RuntimeException(__('xpay::app.errors.order'));
        }
    }
}
