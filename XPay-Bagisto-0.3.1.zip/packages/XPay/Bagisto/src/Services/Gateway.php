<?php

namespace XPay\Bagisto\Services;

use Illuminate\Support\Facades\Http;
use RuntimeException;

final class Gateway
{
    /**
     * Send an authenticated, bounded request to the configured facilitator.
     */
    public function call(string $path, array $body, string $id, ?string $channel = null): array
    {
        Settings::validate($channel);
        if (
            Settings::sandbox($channel)
            || ($body['paymentRequirements']['network'] ?? '') !== Networks::BASE
            || ! in_array($path, ['verify', 'settle'], true)
        ) {
            throw new RuntimeException(__('xpay::app.errors.network'));
        }
        $r = Http::withToken((string) Settings::get('api_key', $channel))->withHeaders(['Idempotency-Key' => $id])->timeout(30)->connectTimeout(8)->withOptions(['allow_redirects' => false])->post(rtrim((string) Settings::get('facilitator_url', $channel), '/').'/'.$path, $body);
        if (
            ! $r->successful()
            || ! is_array($r->json())
        ) {
            throw new RuntimeException(__('xpay::app.errors.provider'));
        }

        return $r->json();
    }

    /**
     * Verify successful settlement against the expected token, payer, amount and nonce.
     */
    public function receipt(string $tx, string $network = Networks::BASE, ?string $channel = null): ?array
    {
        if ($this->rpc('eth_chainId', [], $channel) !== Networks::get($network)['hexChainId']) {
            throw new RuntimeException(__('xpay::app.errors.network'));
        }

        return $this->rpc('eth_getTransactionReceipt', [$tx], $channel);
    }

    /**
     * Read the original network transaction for settlement verification.
     */
    public function transaction(string $tx, string $network, ?string $channel = null): ?array
    {
        return $this->rpc('eth_getTransactionByHash', [$tx], $channel);
    }

    /**
     * Send a bounded request to the trusted channel RPC endpoint.
     */
    private function rpc(string $method, array $params, ?string $channel): mixed
    {
        Settings::validate($channel);
        if (Settings::sandbox($channel)) {
            throw new RuntimeException(__('xpay::app.errors.network'));
        }
        $r = Http::timeout(15)->connectTimeout(5)->withOptions(['allow_redirects' => false])->post(Settings::get('rpc_url', $channel), ['jsonrpc' => '2.0', 'id' => 1, 'method' => $method, 'params' => $params]);
        $d = $r->json();
        if (
            ! $r->successful()
            || ! is_array($d)
            || isset($d['error'])
        ) {
            throw new RuntimeException(__('xpay::app.errors.provider'));
        }

        return $d['result'] ?? null;
    }
}
