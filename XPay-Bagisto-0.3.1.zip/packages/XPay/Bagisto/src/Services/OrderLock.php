<?php

namespace XPay\Bagisto\Services;

use Illuminate\Support\Facades\Cache;

final class OrderLock
{
    /**
     * Serialize payment operations using the configured shared atomic-lock cache.
     */
    public static function run(string $key, callable $fn): mixed
    {

        return Cache::lock('xpay:'.hash('sha256', config('app.url').':'.$key), 180)->block(5, $fn);
    }
}
