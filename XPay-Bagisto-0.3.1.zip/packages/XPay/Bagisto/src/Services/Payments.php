<?php

namespace XPay\Bagisto\Services;

use Illuminate\Support\Facades\DB;
use RuntimeException;
use Webkul\Checkout\Models\Cart;
use Webkul\Sales\Models\Order;
use Webkul\Sales\Repositories\InvoiceRepository;
use Webkul\Sales\Repositories\OrderRepository;
use Webkul\Sales\Repositories\OrderTransactionRepository;
use XPay\Bagisto\Models\Intent;

final class Payments
{
    /**
     * Resolve the payment and Bagisto order repositories.
     */
    public function __construct(private Gateway $gateway, private OrderRepository $orders, private InvoiceRepository $invoices, private OrderTransactionRepository $transactions) {}

    /**
     * Verify and reconcile one payment while holding the shared cart lock.
     */
    public function process(Intent $intent, ?array $payload): array
    {
        return OrderLock::run('cart:'.$intent->cart_id, function () use ($intent, $payload) {
            $intent->refresh();
            if ($intent->status === 'paid') {
                return ['paid' => true, 'transaction' => $intent->payment_reference ?: $intent->transaction_hash];
            }
            if ($intent->status === 'review') {
                return ['paid' => false, 'pending' => true, 'requiresMerchantReview' => true];
            }
            if (in_array($intent->status, ['canceled', 'expired'], true)) {
                throw new RuntimeException(__('xpay::app.errors.expired'));
            }
            $channel = $intent->channel_code;
            Settings::validate($channel);
            if (($intent->mode === 'sandbox') !== Settings::sandbox($channel)) {
                throw new RuntimeException(__('xpay::app.errors.mode'));
            }
            $q = $intent->quote;
            if (($q['terms']['network'] ?? '') !== Networks::BASE) {
                throw new RuntimeException(__('xpay::app.errors.network'));
            }
            if (
                ! $intent->transaction_hash
                && ! $intent->order_id
            ) {
                app(Snapshots::class)->validateBeforePayment($intent);
            }
            if ($intent->mode === 'sandbox') {
                if ($payload !== ['sandbox' => true]) {
                    throw new RuntimeException(__('xpay::app.errors.authorization'));
                }
                if ($q['expires'] <= time()) {
                    throw new RuntimeException(__('xpay::app.errors.expired'));
                }
                $intent->payment_reference = 'sandbox_'.$intent->id.'_'.$q['nonce'];
                $intent->save();

                return $this->finalize($intent);
            }
            if (! $intent->authorization) {
                if (! $payload) {
                    throw new RuntimeException(__('xpay::app.errors.authorization'));
                }
                Rules::validate($payload, $q, time());
                $v = $this->gateway->call('verify', ['x402Version' => 2, 'paymentPayload' => $payload, 'paymentRequirements' => $q['terms']], 'bagisto-'.$intent->id.'-'.$q['nonce'], $channel);
                if (($v['isValid'] ?? false) !== true) {
                    throw new RuntimeException(__('xpay::app.errors.verification'));
                }
                $intent->authorization = $payload;
                $intent->status = 'submitted';
                $intent->save();
                Cart::whereKey($intent->cart_id)->update(['is_active' => 0]);
            }
            if (! $intent->transaction_hash) {
                try {
                    $s = $this->gateway->call('settle', ['x402Version' => 2, 'paymentPayload' => $intent->authorization, 'paymentRequirements' => $q['terms']], 'bagisto-'.$intent->id.'-'.$q['nonce'], $channel);
                    $tx = strtolower($s['transaction'] ?? '');
                    if (
                        ($s['network'] ?? '') !== Networks::BASE
                        || ! preg_match('/^0x[a-f0-9]{64}$/D', $tx)
                    ) {
                        throw new RuntimeException(__('xpay::app.errors.provider'));
                    }
                    DB::transaction(function () use ($intent, $tx) {
                        $intent->transaction_hash = $tx;
                        $intent->payment_reference = $tx;
                        $intent->save();
                    });
                } catch (\Throwable $e) {
                    Audit::failure('settlement', $intent, $e);

                    return ['paid' => false, 'pending' => true];
                }
            }
            try {
                $receipt = $this->gateway->receipt($intent->transaction_hash, Networks::BASE, $channel);
                if (! $receipt) {
                    return ['paid' => false, 'pending' => true];
                }
                Rules::receipt($receipt, $q, Rules::payer($intent->authorization, Networks::BASE), $intent->transaction_hash);
            } catch (\Throwable $e) {
                Audit::failure('receipt', $intent, $e);

                return ['paid' => false, 'pending' => true];
            }

            $intent->status = 'verified';
            $intent->save();

            return $this->finalize($intent);
        });
    }

    /**
     * Create and invoice the order exactly once from verified payment evidence.
     */
    private function finalize(Intent $intent): array
    {
        try {
            DB::transaction(function () use ($intent) {
                $intent->refresh();
                $q = $intent->quote;
                $reference = ['network' => $q['terms']['network'], 'transaction' => $intent->transaction_hash, 'reference' => $intent->payment_reference, 'asset' => $q['terms']['asset'], 'amountAtomic' => $q['terms']['amount'], 'mode' => $intent->mode];
                $order = $intent->order_id ? $this->orders->findOrFail($intent->order_id) : null;
                if (! $order) {
                    if ($this->orders->findOneWhere(['cart_id' => $intent->cart_id])) {
                        throw new RuntimeException(__('xpay::app.errors.order'));
                    }
                    $data = app(Snapshots::class)->read($intent);
                    if (
                        ! is_array($data)
                        || ($data['order_currency_code'] ?? '') !== 'USD'
                        || ($data['base_currency_code'] ?? '') !== 'USD'
                        || Rules::amount((string) $data['grand_total']) !== $q['terms']['amount']
                    ) {
                        throw new RuntimeException(__('xpay::app.errors.order'));
                    }
                    $data['payment']['additional'] = array_merge($data['payment']['additional'] ?? [], ['xpay' => $reference]);
                    $order = $this->orders->create($data);
                    $intent->order_id = $order->id;
                    $intent->save();
                }
                $order = $order->newQuery()->whereKey($order->id)->lockForUpdate()->firstOrFail();
                if (
                    in_array($order->status, [Order::STATUS_CANCELED, Order::STATUS_CLOSED, Order::STATUS_FRAUD], true)
                    || $order->payment?->method !== 'xpay'
                    || $order->order_currency_code !== 'USD'
                    || $order->base_currency_code !== 'USD'
                    || Rules::amount((string) $order->grand_total) !== $q['terms']['amount']
                ) {
                    throw new RuntimeException(__('xpay::app.errors.order'));
                }
                $items = [];
                foreach ($order->items as $item) {
                    if ($item->qty_to_invoice > 0) {
                        $items[$item->id] = $item->qty_to_invoice;
                    }
                }
                $invoice = $items ? $this->invoices->create(['order_id' => $order->id, 'invoice' => ['items' => $items]], 'paid') : $order->invoices()->first();
                if (! $invoice) {
                    throw new RuntimeException(__('xpay::app.errors.order'));
                }
                foreach ($order->invoices()->get() as $existingInvoice) {
                    if ($existingInvoice->state !== 'paid') {
                        $this->invoices->updateState($existingInvoice, 'paid');
                    }
                }
                $existingTransaction = $this->transactions->findOneWhere(['transaction_id' => $intent->payment_reference ?: $intent->transaction_hash]);
                if (
                    $existingTransaction
                    && (int) $existingTransaction->order_id !== (int) $order->id
                ) {
                    throw new RuntimeException(__('xpay::app.errors.order'));
                }
                if (! $existingTransaction) {
                    $this->transactions->create(['transaction_id' => $intent->payment_reference ?: $intent->transaction_hash, 'status' => 'paid', 'type' => $intent->mode === 'sandbox' ? 'xpay_sandbox' : 'xpay', 'payment_method' => 'xpay', 'order_id' => $order->id, 'invoice_id' => $invoice->id, 'amount' => $order->base_grand_total, 'data' => json_encode($reference)]);
                }
                $order->payment->additional = array_merge($order->payment->additional ?? [], ['xpay' => $reference]);
                $order->payment->save();
                Cart::whereKey($intent->cart_id)->update(['is_active' => 0]);
                $intent->status = 'paid';
                $intent->save();
            });
        } catch (\Throwable $e) {
            Audit::failure('order-finalization', $intent, $e);
            $intent->refresh();
            $intent->status = 'review';
            $intent->save();

            return ['paid' => false, 'pending' => true, 'requiresMerchantReview' => true];
        }

        return ['paid' => true, 'transaction' => $intent->payment_reference ?: $intent->transaction_hash];
    }
}
