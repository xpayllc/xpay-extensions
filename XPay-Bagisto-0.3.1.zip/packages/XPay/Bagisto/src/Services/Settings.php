<?php

namespace XPay\Bagisto\Services;

use RuntimeException;

final class Settings
{
    /**
     * Read the requested network or channel-specific payment setting.
     */
    public static function get(string $field, ?string $channel = null): mixed
    {
        return core()->getConfigData('sales.payment_methods.xpay.'.$field, $channel);
    }

    /**
     * Determine whether the channel uses simulated, non-financial test payments.
     */
    public static function sandbox(?string $channel = null): bool
    {
        return (bool) self::get('test_mode', $channel);
    }

    /**
     * Validate the configured payment or authorization before it can be used.
     */
    public static function validate(?string $channel = null): void
    {
        if (
            ! self::get('active', $channel)
            || ! preg_match('/^0x[a-fA-F0-9]{40}$/D', (string) self::get('recipient', $channel))
        ) {
            throw new RuntimeException(__('xpay::app.errors.configuration'));
        }
        if (! self::sandbox($channel)) {
            if (! self::get('api_key', $channel)) {
                throw new RuntimeException(__('xpay::app.errors.configuration'));
            }
            foreach (['facilitator_url', 'rpc_url'] as $field) {
                $url = (string) self::get($field, $channel);
                if (
                    filter_var($url, FILTER_VALIDATE_URL) === false
                    || parse_url($url, PHP_URL_SCHEME) !== 'https'
                    || parse_url($url, PHP_URL_USER) !== null
                    || parse_url($url, PHP_URL_FRAGMENT) !== null
                ) {
                    throw new RuntimeException(__('xpay::app.errors.configuration'));
                }
            }
        }
    }
}
