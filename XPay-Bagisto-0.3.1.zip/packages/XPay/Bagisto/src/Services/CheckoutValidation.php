<?php

namespace XPay\Bagisto\Services;

use RuntimeException;
use Webkul\Checkout\Facades\Cart;

final class CheckoutValidation
{
    /** Validate the supported cart through public services, without an internal shop controller. */
    public function validate($cart): void
    {
        if (! $cart) {
            throw new RuntimeException(__('xpay::app.errors.order'));
        }
        Settings::validate($cart->channel?->code);
        $customer = $cart->customer;
        if (
            ($customer
            && ($customer->is_suspended
            || ! $customer->status))
            || ! Cart::haveMinimumOrderAmount()
        ) {
            throw new RuntimeException(__('xpay::app.errors.order'));
        }
        if (
            ! $cart->billing_address
            || ($cart->haveStockableItems()
            && (! $cart->shipping_address
            || ! $cart->selected_shipping_rate))
        ) {
            throw new RuntimeException(__('xpay::app.errors.order'));
        }
        if ($cart->payment?->method !== 'xpay') {
            throw new RuntimeException(__('xpay::app.errors.order'));
        }
    }
}
