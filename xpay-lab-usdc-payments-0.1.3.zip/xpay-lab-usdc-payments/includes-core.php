<?php
defined('ABSPATH') || exit;
final class XPay_Core {
    const NETWORK = 'eip155:8453';
    const ASSET = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913';
    const TRANSFER = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef';
    public static function settings() { return get_option('woocommerce_xpay_settings', []); }
    public static function key() { return defined('XPAY_FACILITATOR_KEY') ? XPAY_FACILITATOR_KEY : (self::settings()['api_key'] ?? ''); }
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = $wpdb->prefix . 'xpay_receipts';
        dbDelta("CREATE TABLE $table (
            order_id bigint unsigned NOT NULL,
            transaction_hash varchar(66) NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (order_id),
            UNIQUE KEY transaction_hash (transaction_hash)
        ) " . $wpdb->get_charset_collate() . ';');
    }
    public static function amount($total) {
        $total = (string)$total;
        if (!preg_match('/^([0-9]{1,10})(?:\.([0-9]{1,6}))?$/D', $total, $m)) throw new Exception('USDC total must be positive with at most six decimals.');
        $units = ltrim($m[1] . str_pad($m[2] ?? '', 6, '0'), '0');
        if ($units === '') throw new Exception('Zero-value orders do not require XPay.');
        return $units;
    }
    public static function configured() {
        $s = self::settings();
        return PHP_INT_SIZE >= 8 && ($s['enabled'] ?? '') === 'yes' && preg_match('/^0x[a-fA-F0-9]{40}$/D', $s['wallet'] ?? '') && self::key() !== '' && is_ssl();
    }
    public static function routes() {
        register_rest_route('xpay/v1', '/orders/(?P<id>\d+)/payment', [
            'methods' => ['GET', 'POST'], 'callback' => [__CLASS__, 'payment'], 'permission_callback' => [__CLASS__, 'permission'],
        ]);
    }
    public static function permission($request) {
        if (!is_ssl()) return new WP_Error('xpay_https', 'HTTPS is required.', ['status'=>403]);
        $order = wc_get_order((int)$request['id']);
        $key = (string)($request->get_header('x-xpay-order-key') ?: $request->get_param('key'));
        if (!$order || !$key || !hash_equals($order->get_order_key(), $key)) return new WP_Error('xpay_access', 'Invalid order access.', ['status'=>403]);
        return true;
    }
    private static function remote($path, $body, $idem) {
        $result = wp_safe_remote_post('https://facilitator-xpay.llc/' . $path, [
            'timeout'=>45, 'redirection'=>0, 'headers'=>['Authorization'=>'Bearer ' . self::key(), 'Content-Type'=>'application/json', 'Idempotency-Key'=>$idem],
            'body'=>wp_json_encode($body), 'limit_response_size'=>65536,
        ]);
        if (is_wp_error($result)) throw new Exception('Facilitator connection is uncertain. Keep this order pending and retry the same payment.');
        $json = json_decode(wp_remote_retrieve_body($result), true);
        if (!is_array($json)) throw new Exception('Facilitator returned an unreadable response. Payment remains pending.');
        return ['code'=>wp_remote_retrieve_response_code($result), 'data'=>$json];
    }
    private static function rpc($method, $params) {
        $result = wp_safe_remote_post('https://mainnet.base.org', ['timeout'=>20, 'redirection'=>0, 'headers'=>['Content-Type'=>'application/json'], 'body'=>wp_json_encode(['jsonrpc'=>'2.0','id'=>1,'method'=>$method,'params'=>$params]), 'limit_response_size'=>262144]);
        if (is_wp_error($result)) throw new Exception('Base receipt lookup unavailable. Keep the order pending.');
        $data = json_decode(wp_remote_retrieve_body($result), true);
        if (!is_array($data) || isset($data['error'])) throw new Exception('Base receipt lookup unavailable. Keep the order pending.');
        return $data['result'] ?? null;
    }
    private static function confirm_receipt($tx, $terms, $payer) {
        $receipt = self::rpc('eth_getTransactionReceipt', [$tx]);
        if (!$receipt || ($receipt['status'] ?? '') !== '0x1') throw new Exception('Payment does not yet have a successful Base receipt.');
        foreach (($receipt['logs'] ?? []) as $log) {
            $t = $log['topics'] ?? [];
            if (strtolower($log['address'] ?? '') !== strtolower(self::ASSET) || count($t) !== 3 || strtolower($t[0]) !== self::TRANSFER) continue;
            if (strtolower('0x'.substr($t[1],-40)) !== strtolower($payer) || strtolower('0x'.substr($t[2],-40)) !== strtolower($terms['payTo'])) continue;
            // Supported order totals fit safely within 64-bit PHP integers (up to 10 billion USDC).
            $hex = ltrim(substr($log['data'] ?? '', 2), '0');
            if (strlen($hex) <= 14 && (string)hexdec($hex ?: '0') === $terms['amount']) return;
        }
        throw new Exception('The Base receipt does not contain the expected merchant USDC transfer.');
    }
    private static function paid_response($order) {
        return new WP_REST_Response(['paid'=>true, 'transaction'=>$order->get_transaction_id(), 'redirect'=>$order->get_checkout_order_received_url()], 200, ['Cache-Control'=>'no-store']);
    }
    public static function payment($request) {
        global $wpdb;
        $id = (int)$request['id'];
        $lock = 'xpay_' . substr(hash('sha256', $wpdb->prefix . ':' . $id), 0, 40);
        // Atomic advisory locks must hit the database; cached results cannot serialize payments.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', $lock)) !== '1') return new WP_Error('xpay_busy', 'Payment is being checked. Retry shortly.', ['status'=>409]);
        try {
            $order = wc_get_order($id);
            if ($order->is_paid()) return self::paid_response($order);
            if (!self::configured()) throw new Exception('XPay is not configured by this merchant.');
            if (!$order->needs_payment() || $order->get_payment_method() !== 'xpay') throw new Exception('This order is not payable with XPay.');
            if (!in_array($order->get_currency(), ['USD','USDC'], true)) throw new Exception('Version 0.1 supports USD/USDC stores only.');
            $amount = self::amount($order->get_total());
            $quote = $order->get_meta('_xpay_quote', true);
            $stored = $order->get_meta('_xpay_payload', true);
            if (!$quote || (!$stored && $quote['expires'] < time())) {
                $quote = ['nonce'=>'0x'.bin2hex(random_bytes(32)), 'expires'=>time()+600, 'terms'=>['scheme'=>'exact', 'network'=>self::NETWORK, 'amount'=>$amount, 'asset'=>self::ASSET, 'payTo'=>self::settings()['wallet'], 'maxTimeoutSeconds'=>600, 'extra'=>['name'=>'USD Coin','version'=>'2']]];
                $order->update_meta_data('_xpay_quote', $quote); $order->save();
            }
            if ($amount !== $quote['terms']['amount']) throw new Exception('Order total changed. Merchant review is required before paying.');
            if ($request->get_method() === 'GET' && !$stored) {
                $body = ['x402Version'=>2, 'resource'=>['url'=>rest_url('xpay/v1/orders/'.$id.'/payment'), 'description'=>'WooCommerce order '.$order->get_order_number(), 'mimeType'=>'application/json'], 'accepts'=>[$quote['terms']], 'extensions'=>['xpay-order'=>['nonce'=>$quote['nonce'], 'expires'=>$quote['expires']]]];
                return new WP_REST_Response($body, 402, ['PAYMENT-REQUIRED'=>base64_encode(wp_json_encode($body)), 'Cache-Control'=>'no-store']);
            }
            if (!$stored) {
                if ($quote['expires'] < time()) throw new Exception('Payment quote expired. Reload checkout.');
                $raw = $request->get_header('payment-signature');
                $payload = $raw ? json_decode(base64_decode($raw, true) ?: '', true) : ($request->get_json_params()['paymentPayload'] ?? null);
                $auth = $payload['payload']['authorization'] ?? [];
                if (!is_array($payload) || ($payload['x402Version'] ?? null) !== 2 || ($payload['accepted'] ?? null) != $quote['terms'] || ($auth['nonce'] ?? '') !== $quote['nonce'] || (string)($auth['value'] ?? '') !== $amount || strtolower($auth['to'] ?? '') !== strtolower($quote['terms']['payTo']) || (int)($auth['validBefore'] ?? 0) > $quote['expires'] || !preg_match('/^0x[a-fA-F0-9]{40}$/D', $auth['from'] ?? '')) throw new Exception('Payment authorization must match this order and quote.');
                $body = ['x402Version'=>2,'paymentPayload'=>$payload,'paymentRequirements'=>$quote['terms']];
                $verified = self::remote('verify', $body, 'wc-'.$id.'-'.$quote['nonce']);
                if ($verified['code'] !== 200 || ($verified['data']['isValid'] ?? false) !== true) throw new Exception('XPay could not verify the payment authorization.');
                // Persist before settlement: any timeout must reconcile this exact authorization.
                $stored = $payload; $order->update_meta_data('_xpay_payload', $stored); $order->save();
            }
            $body = ['x402Version'=>2,'paymentPayload'=>$stored,'paymentRequirements'=>$quote['terms']];
            $result = self::remote('settle', $body, 'wc-'.$id.'-'.$quote['nonce']);
            $data = $result['data'];
            $tx = strtolower($data['transaction'] ?? '');
            if (($data['success'] ?? false) !== true || !preg_match('/^0x[a-f0-9]{64}$/D', $tx) || ($data['network'] ?? '') !== self::NETWORK) {
                return new WP_REST_Response(['paid'=>false,'pending'=>true,'message'=>'Settlement is not confirmed. Retry this same order; do not create another payment.'], 202, ['Cache-Control'=>'no-store']);
            }
            self::confirm_receipt($tx, $quote['terms'], $stored['payload']['authorization']['from']);
            $table = $wpdb->prefix . 'xpay_receipts';
            // This uniqueness check must observe the current transaction ledger, not a cache.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $existing = $wpdb->get_var($wpdb->prepare('SELECT transaction_hash FROM %i WHERE order_id = %d', $table, $id));
            // Direct atomic insert enforces the database UNIQUE receipt constraint.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            if (!$existing && !$wpdb->insert($table, ['order_id'=>$id,'transaction_hash'=>$tx,'created_at'=>current_time('mysql',true)], ['%d','%s','%s'])) throw new Exception('Receipt is already assigned or could not be recorded. Merchant review required.');
            if ($existing && !hash_equals($existing, $tx)) throw new Exception('Order receipt conflict. Merchant review required.');
            $order->payment_complete($tx);
            $order->add_order_note('XPay confirmed Base USDC payment: '.$tx);
            $order->delete_meta_data('_xpay_payload'); $order->save();
            $response = self::paid_response($order);
            $response->header('PAYMENT-RESPONSE', base64_encode(wp_json_encode($data)));
            return $response;
        } catch (Throwable $e) {
            return new WP_Error('xpay_payment', $e->getMessage(), ['status'=>422]);
        } finally {
            // Advisory lock release is an uncached database operation by definition.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }
}
