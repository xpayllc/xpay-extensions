(function () {
    'use strict';
    const config = window.XPayCheckout;
    const pay = document.getElementById('xpay-connect');
    const retry = document.getElementById('xpay-recheck');
    const status = document.getElementById('xpay-status');
    if (!config || !pay || !status) return;
    let busy = false;
    async function request(method, payload) {
        const response = await fetch(config.url, {method, cache: 'no-store', credentials: 'same-origin', headers: {
            'Content-Type': 'application/json', 'X-XPay-Order-Key': config.key
        }, ...(payload ? {body: JSON.stringify({paymentPayload: payload})} : {})});
        const data = await response.json();
        if (![200, 202, 402].includes(response.status)) throw new Error(data.message || 'Payment check failed. Keep this order open and try again.');
        return data;
    }
    function completed(data) {
        if (!data.paid) return false;
        status.textContent = 'Payment confirmed. Opening your order…';
        window.location.assign(data.redirect);
        return true;
    }
    async function recheck() {
        if (busy) return;
        busy = true; retry.disabled = true;
        try {
            status.textContent = 'Checking the existing payment…';
            const data = await request('GET');
            if (!completed(data)) status.textContent = data.pending ? 'Payment is still pending. Check again shortly.' : 'No payment has been submitted. Use Connect wallet and pay.';
        } catch (error) { status.textContent = error.message; }
        finally { busy = false; retry.disabled = false; }
    }
    retry.addEventListener('click', recheck);
    pay.addEventListener('click', async function () {
        if (busy) return;
        busy = true; pay.disabled = true;
        let submitted = false;
        try {
            status.textContent = 'Loading the order payment quote…';
            const quote = await request('GET');
            if (completed(quote)) return;
            if (quote.pending) { submitted = true; throw new Error('An existing payment is pending. Use Check payment again.'); }
            if (!window.ethereum) throw new Error('Open this page in a wallet browser or install an Ethereum-compatible browser wallet.');
            const terms = quote.accepts[0];
            const account = (await window.ethereum.request({method: 'eth_requestAccounts'}))[0];
            await window.ethereum.request({method: 'wallet_switchEthereumChain', params: [{chainId: '0x2105'}]});
            const auth = {from: account, to: terms.payTo, value: terms.amount, validAfter: '0', validBefore: String(quote.extensions['xpay-order'].expires), nonce: quote.extensions['xpay-order'].nonce};
            const typed = {
                types: {
                    EIP712Domain: [{name:'name',type:'string'},{name:'version',type:'string'},{name:'chainId',type:'uint256'},{name:'verifyingContract',type:'address'}],
                    TransferWithAuthorization: [{name:'from',type:'address'},{name:'to',type:'address'},{name:'value',type:'uint256'},{name:'validAfter',type:'uint256'},{name:'validBefore',type:'uint256'},{name:'nonce',type:'bytes32'}]
                }, primaryType: 'TransferWithAuthorization',
                domain: {name:'USD Coin',version:'2',chainId:8453,verifyingContract:terms.asset}, message: auth
            };
            status.textContent = `Review ${(Number(terms.amount) / 1e6).toFixed(6)} USDC to ${terms.payTo} in your wallet.`;
            const signature = await window.ethereum.request({method:'eth_signTypedData_v4',params:[account,JSON.stringify(typed)]});
            submitted = true;
            retry.hidden = false;
            status.textContent = 'Submitting your authorization. Please keep this page open…';
            const data = await request('POST', {x402Version:2,resource:quote.resource,accepted:terms,payload:{signature,authorization:auth}});
            if (!completed(data)) status.textContent = 'Settlement is pending. Use Check payment again; do not sign another payment.';
        } catch (error) { status.textContent = error.code === 4001 ? 'Wallet request cancelled. No new authorization was submitted.' : error.message; }
        finally { busy = false; pay.disabled = submitted; retry.hidden = !submitted; }
    });
}());
