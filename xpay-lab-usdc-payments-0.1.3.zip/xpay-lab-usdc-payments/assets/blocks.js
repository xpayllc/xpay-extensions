(function () {
    'use strict';
    const config = window.wc.wcSettings.getSetting('xpay_data', {});
    const el = window.wp.element.createElement;
    const content = el('p', null, config.description || 'Pay in USDC on Base.');
    window.wc.wcBlocksRegistry.registerPaymentMethod({
        name: 'xpay', label: el('span', {style:{display:'inline-flex',alignItems:'center',gap:'10px'}}, config.icon ? el('img',{src:config.icon,alt:'XPay',style:{width:'94px',height:'24px',objectFit:'contain',background:'#16220b',borderRadius:'4px'}}) : null, config.title || 'Pay with XPay'),
        content, edit: content, canMakePayment: () => true,
        ariaLabel: 'Pay with XPay USDC', supports: {features: config.supports || ['products']}
    });
}());
