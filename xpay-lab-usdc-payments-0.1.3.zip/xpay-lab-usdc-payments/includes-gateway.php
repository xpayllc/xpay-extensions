<?php
defined('ABSPATH') || exit;
class XPay_Gateway extends WC_Payment_Gateway {
    public function __construct() {
        $this->icon=plugins_url('assets/xpay-logo.png',XPAY_FILE);
        $this->id='xpay'; $this->method_title='XPay USDC';
        $this->method_description='Accept Base USDC with XPay. Validate on a staging store before accepting live orders.';
        $this->has_fields=false; $this->supports=['products'];
        $this->init_form_fields(); $this->init_settings();
        $this->title=$this->get_option('title','Pay with XPay');
        $this->description='Pay in USDC on Base using your wallet or a payment-capable agent.';
        $this->enabled=$this->get_option('enabled','no');
        add_action('woocommerce_update_options_payment_gateways_xpay', [$this,'process_admin_options']);
        add_action('woocommerce_receipt_xpay', [$this,'receipt']);
    }
    public function init_form_fields() {
        $this->form_fields=[
            'enabled'=>['title'=>'Enable XPay','type'=>'checkbox','label'=>'Enable Base USDC checkout','default'=>'no'],
            'title'=>['title'=>'Checkout label','type'=>'text','default'=>'Pay with XPay'],
            'wallet'=>['title'=>'Merchant receiving wallet','type'=>'text','description'=>'Your Base wallet address. Never enter a private key. Payment goes directly here.'],
            'api_key'=>['title'=>'XPay facilitator API key','type'=>'password','description'=>'Server-side merchant credential. Prefer defining XPAY_FACILITATOR_KEY in wp-config.php. Never use a wallet private key.'],
        ];
    }
    public function validate_wallet_field($key,$value) {
        $value=trim($value);
        if ($value && !preg_match('/^0x[a-fA-F0-9]{40}$/D',$value)) { WC_Admin_Settings::add_error('XPay: enter a valid Base receiving address.'); return $this->get_option('wallet'); }
        return $value;
    }
    public function is_available() { return parent::is_available() && XPay_Core::configured() && in_array(get_woocommerce_currency(),['USD','USDC'],true) && PHP_INT_SIZE >= 8; }
    public function process_payment($order_id) {
        $order=wc_get_order($order_id);
        if (!$this->is_available() || !$order || !$order->needs_payment()) return ['result'=>'failure'];
        return ['result'=>'success','redirect'=>$order->get_checkout_payment_url(true)];
    }
    public function receipt($order_id) {
        $order=wc_get_order($order_id);
        if (!$order || $order->get_payment_method() !== 'xpay') return;
        wp_enqueue_style('xpay-checkout', plugins_url('assets/checkout.css',XPAY_FILE), [],XPAY_VERSION);
        wp_enqueue_script('xpay-checkout',plugins_url('assets/checkout.js',XPAY_FILE),[],XPAY_VERSION,true);
        wp_add_inline_script('xpay-checkout','window.XPayCheckout='.wp_json_encode(['url'=>rest_url('xpay/v1/orders/'.$order_id.'/payment'),'key'=>$order->get_order_key()]).';','before');
        echo '<section class="xpay-checkout"><img class="xpay-logo" src="'.esc_url(plugins_url('assets/xpay-logo.png',XPAY_FILE)).'" alt="XPay" width="156" height="40"><span class="xpay-badge">XPay · Base USDC</span><h2>Pay securely with your wallet</h2><p>The payment amount and receiving wallet will be shown before you sign. Keep this page open while your payment is checked.</p><button type="button" id="xpay-connect">Connect wallet and pay</button><button type="button" id="xpay-recheck" hidden>Check payment again</button><p id="xpay-status" role="status" aria-live="polite"></p><details><summary>Pay with an AI agent</summary><p>Give your authorized payment agent this endpoint and the order access key below. Treat the key as a private checkout link.</p><code>'.esc_html(rest_url('xpay/v1/orders/'.$order_id.'/payment')).'</code><p>Header: X-XPay-Order-Key: <code>'.esc_html($order->get_order_key()).'</code></p><p>The agent must support XPay order-bound x402 v2 authorizations. See the plugin integration guide.</p></details></section>';
    }
}
