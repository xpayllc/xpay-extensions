<?php
/**
 * Plugin Name: X PAY LAB USDC Payments for WooCommerce
 * Description: Accept Base USDC with XPay x402 from connected wallets and payment-capable agents.
 * Version: 0.1.3
 * Requires at least: 6.5
 * Requires PHP: 8.0
 * Requires Plugins: woocommerce
 * Author: X PAY LAB LIMITED
 * Author URI: https://x-pay.llc
 * License: GPL-2.0-or-later
 * Text Domain: xpay-lab-usdc-payments
 * WC requires at least: 8.3
 */
defined('ABSPATH') || exit;
define('XPAY_VERSION', '0.1.3');
define('XPAY_FILE', __FILE__);
require_once __DIR__ . '/includes-core.php';
register_activation_hook(__FILE__, ['XPay_Core', 'install']);
add_action('before_woocommerce_init', function () {
    if (class_exists('Automattic\\WooCommerce\\Utilities\\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', XPAY_FILE, true);
    }
});
add_action('plugins_loaded', function () {
    if (!class_exists('WC_Payment_Gateway')) {
        add_action('admin_notices', function () { echo '<div class="notice notice-warning"><p>XPay Payments requires WooCommerce.</p></div>'; });
        return;
    }
    require_once __DIR__ . '/includes-gateway.php';
    add_filter('woocommerce_payment_gateways', function ($gateways) { $gateways[] = 'XPay_Gateway'; return $gateways; });
    add_action('rest_api_init', ['XPay_Core', 'routes']);
});
add_action('woocommerce_blocks_loaded', function () {
    if (!class_exists('Automattic\\WooCommerce\\Blocks\\Payments\\Integrations\\AbstractPaymentMethodType')) return;
    require_once __DIR__ . '/includes-blocks.php';
    add_action('woocommerce_blocks_payment_method_type_registration', function ($registry) { $registry->register(new XPay_Blocks()); });
});
