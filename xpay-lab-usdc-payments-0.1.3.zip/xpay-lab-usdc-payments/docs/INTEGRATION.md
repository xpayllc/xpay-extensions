# XPay WooCommerce integration — 0.1.0 review release

## Scope
Installable WordPress/WooCommerce plugin with Base mainnet USDC checkout and existing-order agent payments. This is a review package, not a production-certified gateway. Merchant facilitator enrollment and settlement permissions must be confirmed. WordPress.org submission is separate. There is no BNB, content paywall, currency conversion, card processing, wallet custody, automatic refund, recurring authorization or autonomous order-creation capability in this release.

## Merchant setup
Use HTTPS, 64-bit PHP 8+, WordPress 6.5+, WooCommerce 8.3+. Upload the ZIP, activate, then configure WooCommerce > Settings > Payments > XPay USDC. Set the merchant Base recipient and API key. The preferred secret configuration is:

```php
define('XPAY_FACILITATOR_KEY', 'YOUR_MERCHANT_API_KEY');
```

Use a distinct merchant credential for each independent store. Merchant keys must be valid for verification and settlement. Do not paste funder keys or buyer keys into the plugin. Shared hosting must support MySQL/MariaDB named locks. The plugin fails closed when it cannot lock an order.

## Agent flow
Create an order through the store's authorized WooCommerce checkout/order API with payment method `xpay`. Supply all ordinary order details and obtain its private order key. Send the key in the `X-XPay-Order-Key` header to avoid putting it in URLs.

1. `GET /wp-json/xpay/v1/orders/ORDER_ID/payment`
2. HTTP 402 returns x402 v2 requirements in the JSON body and base64 `PAYMENT-REQUIRED` header.
3. Read `extensions["xpay-order"].nonce` and `.expires`. Sign EIP-3009 TransferWithAuthorization on Base using USDC domain `USD Coin`, version `2`, chain 8453. Use the provided nonce, amount, recipient and expiry. This nonce binding is mandatory: an unmodified generic client choosing a different nonce is rejected.
4. `POST` the same endpoint with `PAYMENT-SIGNATURE: base64(x402-v2-payload)` or JSON `{ "paymentPayload": ... }`. Include `accepted` exactly as returned and `payload.signature`, `payload.authorization`.
5. HTTP 200 with `paid: true` confirms the order. HTTP 202 is pending: retry GET on the SAME order. A 422/connection error following submission can also have an uncertain outcome: reconcile the SAME order, never assume a failure means no transfer happened.

The plugin saves one authorization before submitting, uses a stable order-and-nonce idempotency key, and will not replace that authorization after an ambiguous result. A permanently failed authorization needs merchant/developer review; there is deliberately no unsafe reset button. GET can reconcile an already-authorized settlement but never creates a new authorization. Do not cache these routes.

## Payment confirmation
Verification is server-to-server. Payment completion additionally requires a successful Base receipt with an official USDC Transfer log matching payer, recipient and exact amount. A unique receipt table prevents reuse across orders. Order processing uses a database lock. WooCommerce determines processing/completed status and download permissions using its normal payment_complete flow. The current policy accepts an included successful receipt, not finalized chain state; stronger finality thresholds should be evaluated before larger production payments.

## Acceptance checklist — required before production
- Fresh WordPress + supported WooCommerce install; activation creates receipt table.
- Classic checkout and Checkout Blocks: real order, correct totals, receipt screen, redirect and download access.
- Mobile and desktop injected wallets: reject signature, wrong chain, unavailable wallet.
- Merchant enrollment, key permissions, /supported, /verify and /settle response compatibility.
- No API credentials in page HTML, JS, browser requests or customer errors.
- Tampered amount/recipient/asset/network/nonce, expired signature and incorrect order key rejected.
- Same authorization retried concurrently, browser refreshed, timeout after broadcast and server restart: no duplicate charge or fulfillment.
- Previously used receipt cannot pay a second order; failed/missing/wrong transfer receipt never completes an order.
- Outage/rate-limited Base RPC keeps order pending; facilitator uncertain status cannot unlock downloads.
- Digital and physical orders: stock, shipping, taxes, emails and order status validated.
- HPOS and normal order storage. Named-lock failure and database insert failure.
- Refunds require a separately authorized merchant process; no automatic refund requests.
- Payment-signed order expires/cancels/changes: merchant review and customer resolution process.
- Independent security review and applicable external-service terms/privacy notices.

## Release validation performed
See docs/VALIDATION.md in the package for the actual checks run. No paid transaction, live-store installation, publishing or hosting change is performed by creating this package.
