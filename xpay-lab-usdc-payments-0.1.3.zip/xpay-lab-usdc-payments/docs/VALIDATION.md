# Validation — version 0.1.3 (20 November 2026)

- Official WordPress Plugin Check: zero errors and zero warnings.
- 28 WordPress/WooCommerce integration checks passed in WordPress 7.1.5, WooCommerce 11.3.1 and PHP 8.3.36 using official WordPress Playground.
- Six JavaScript checkout scenarios passed: success, pending payment, connection loss, existing pending payment, wallet rejection and paid-order retry.
- All four PHP files parsed successfully. Distribution ZIP integrity and metadata checks passed.
- Payment implementation files are byte-identical to version 0.1.2; this release changes company identity, package metadata and documentation only.

Scope and limits:
- Facilitator/RPC responses and wallet signatures were mocked. No new live-funds payment was performed.
- SQLite was used; MySQL advisory-lock responses were emulated. Test real MySQL/MariaDB locking on staging before production.
- Full classic/Blocks browser checkout, mobile wallet and real settlement acceptance checks remain required before live merchant use.
- The WordPress.org directory review is ongoing. No approval is claimed.
