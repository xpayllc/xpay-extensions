<?php
defined('ABSPATH') || exit;
class XPay_Blocks extends \Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {
    protected $name='xpay';
    public function initialize() { $this->settings=get_option('woocommerce_xpay_settings',[]); }
    public function is_active() { $gateway=WC()->payment_gateways()->payment_gateways()['xpay'] ?? null; return $gateway && $gateway->is_available(); }
    public function get_payment_method_script_handles() {
        wp_register_script('xpay-blocks',plugins_url('assets/blocks.js',XPAY_FILE),['wc-blocks-registry','wc-settings','wp-element'],XPAY_VERSION,true);
        return ['xpay-blocks'];
    }
    public function get_payment_method_data() { return ['icon'=>plugins_url('assets/xpay-logo.png',XPAY_FILE),'title'=>$this->settings['title'] ?? 'Pay with XPay','description'=>'Pay in USDC on Base. Connect your wallet on the next screen.','supports'=>['products']]; }
}
