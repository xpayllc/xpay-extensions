<?php
$_['heading_title']='XPay x402 USDC Payments';
$_['text_extension']='Extensions';
$_['text_success']='XPay settings saved.';
