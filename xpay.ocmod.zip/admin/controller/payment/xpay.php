<?php
namespace Opencart\Admin\Controller\Extension\Xpay\Payment;
use Opencart\System\Library\Extension\Xpay\Security;

/** Configure Base USDC payments; credentials never enter the storefront. */
class Xpay extends \Opencart\System\Engine\Controller {
    private const DEFAULTS = ['status'=>0, 'sandbox'=>1, 'recipient'=>'', 'api_key'=>'', 'facilitator'=>'https://facilitator-xpay.llc', 'rpc'=>'https://mainnet.base.org', 'order_status_id'=>2, 'sort_order'=>0];
    public function index(): void {
        $this->load->language('extension/xpay/payment/xpay');
        $this->document->setTitle($this->language->get('heading_title'));
        $data = [];
        foreach (self::DEFAULTS as $k=>$v) $data['payment_xpay_'.$k] = $k === 'api_key' ? '' : ($this->config->get('payment_xpay_'.$k) ?? $v);
        $data['key_saved'] = (bool)$this->config->get('payment_xpay_api_key');
        // A provider RPC URL may contain a credential, so it is also masked.
        $data['payment_xpay_rpc'] = '';
        $data['rpc_saved'] = (bool)$this->config->get('payment_xpay_rpc');
        $args='user_token='.$this->session->data['user_token'];
        $data['save']=$this->url->link('extension/xpay/payment/xpay.save', $args);
        $data['back']=$this->url->link('marketplace/extension', $args.'&type=payment');
        $data['breadcrumbs']=[];
        $this->load->model('localisation/order_status');
        $data['order_statuses']=$this->model_localisation_order_status->getOrderStatuses();
        foreach (['header','column_left','footer'] as $v) $data[$v]=$this->load->controller('common/'.$v);
        $this->response->setOutput($this->load->view('extension/xpay/payment/xpay', $data));
    }
    public function save(): void {
        $this->load->language('extension/xpay/payment/xpay');
        $json=[];
        if (!$this->user->hasPermission('modify','extension/xpay/payment/xpay') || ($this->request->server['REQUEST_METHOD'] ?? '') !== 'POST') $json['error']['warning']='Permission denied.';
        $values=[];
        foreach(self::DEFAULTS as $k=>$v) $values['payment_xpay_'.$k]=trim((string)($this->request->post['payment_xpay_'.$k] ?? $v));
        foreach(['api_key','rpc'] as $k) if ($values['payment_xpay_'.$k] === '') $values['payment_xpay_'.$k]=$this->config->get('payment_xpay_'.$k) ?: self::DEFAULTS[$k];
        $error='';
        if (!in_array($values['payment_xpay_status'],['0','1'],true) || !in_array($values['payment_xpay_sandbox'],['0','1'],true)) $error='Invalid mode.';
        if ($values['payment_xpay_status'] === '1') {
            if (!Security::address($values['payment_xpay_recipient'])) $error='Enter a valid non-zero Base recipient address.';
            if ($this->config->get('config_currency') !== 'USD') $error='This release requires USD as the store base currency.';
            if (strlen((string)$this->config->get('config_encryption')) < 16) $error='Configure the OpenCart encryption key first.';
            if ($values['payment_xpay_sandbox'] !== '1' && (strlen($values['payment_xpay_api_key']) < 8 || preg_match('/[\r\n]/',$values['payment_xpay_api_key']))) $error='Enter a valid merchant API key.';
        }
        if (!Security::url($values['payment_xpay_facilitator']) || parse_url($values['payment_xpay_facilitator'], PHP_URL_QUERY) !== null || !Security::url($values['payment_xpay_rpc'])) $error='Use valid public HTTPS facilitator and RPC URLs.';
        $this->load->model('localisation/order_status');
        if (!$this->model_localisation_order_status->getOrderStatus((int)$values['payment_xpay_order_status_id'])) $error='Select a valid paid order status.';
        if (!preg_match('/^-?\d{1,6}$/D',$values['payment_xpay_sort_order'])) $error='Sort order must be an integer.';
        if ($error) $json['error']['warning']=$error;
        if (!$json) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('payment_xpay',$values);
            $json['success']='XPay settings saved.';
        }
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
    public function install(): void {
        if (!$this->user->hasPermission('modify','extension/payment')) return;
        $this->db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX."xpay_payment` (`order_id` INT NOT NULL, `owner` CHAR(64) NOT NULL, `state` VARCHAR(16) NOT NULL, `data` LONGTEXT NOT NULL, `tx` VARCHAR(66) NULL, `date_modified` DATETIME NOT NULL, PRIMARY KEY (`order_id`), UNIQUE KEY `tx` (`tx`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    public function uninstall(): void {
        // Retain payment reconciliation records. Do not silently destroy financial records.
    }
}
