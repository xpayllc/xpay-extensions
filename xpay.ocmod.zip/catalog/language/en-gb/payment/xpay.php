<?php
$_['heading_title']='USDC on Base (XPay)';
