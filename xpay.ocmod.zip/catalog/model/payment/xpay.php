<?php
namespace Opencart\Catalog\Model\Extension\Xpay\Payment;

/** Offer only the tested payment network, currency and one-time checkout. */
class Xpay extends \Opencart\System\Engine\Model {
    public function getMethods(array $address=[]): array {
        if (!$this->config->get('payment_xpay_status') || $this->config->get('config_currency') !== 'USD' || ($this->session->data['currency'] ?? '') !== 'USD' || $this->cart->hasSubscription() || $this->cart->getTotal() <= 0) return [];
        $name='USDC on Base (XPay)'.($this->config->get('payment_xpay_sandbox') ? ' — TEST SIMULATION' : '');
        return ['code'=>'xpay', 'name'=>$name, 'option'=>['xpay'=>['code'=>'xpay.xpay','name'=>$name]], 'sort_order'=>(int)$this->config->get('payment_xpay_sort_order')];
    }
}
