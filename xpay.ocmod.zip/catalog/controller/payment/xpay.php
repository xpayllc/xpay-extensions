<?php
namespace Opencart\Catalog\Controller\Extension\Xpay\Payment;
use Opencart\System\Library\Extension\Xpay\Rules;
use Opencart\System\Library\Extension\Xpay\Security;
use Opencart\System\Library\Extension\Xpay\ServiceError;

/** Session-bound, idempotent USDC authorization and settlement. */
class Xpay extends \Opencart\System\Engine\Controller {
    public function index(): string {
        $this->load->language('extension/xpay/payment/xpay');
        $this->session->data['xpay_csrf'] ??= bin2hex(random_bytes(32));
        $this->session->data['xpay_owner'] ??= bin2hex(random_bytes(32));
        $data['csrf']=$this->session->data['xpay_csrf'];
        $data['endpoint']=$this->url->link('extension/xpay/payment/xpay.pay','language='.$this->config->get('config_language'),true);
        $data['success']=$this->url->link('checkout/success','language='.$this->config->get('config_language'),true);
        $data['sandbox']=(bool)$this->config->get('payment_xpay_sandbox');
        $data['recipient']=(string)$this->config->get('payment_xpay_recipient');
        $data['recipient_short']=substr($data['recipient'],0,8).'…'.substr($data['recipient'],-6);
        $data['display_amount']='—';
        $data['pending']=false;
        $id=(int)($this->session->data['order_id'] ?? 0);
        if ($id) {
            $this->load->model('checkout/order');
            $order=$this->model_checkout_order->getOrder($id);
            if ($order) $data['display_amount']=number_format((float)$order['total'],2,'.','');
            $record=$this->db->query("SELECT state FROM `".DB_PREFIX."xpay_payment` WHERE order_id=".$id)->row;
            $data['pending']=$record && in_array($record['state'],['submitted','settled'],true);
        }
        return $this->load->view('extension/xpay/payment/xpay',$data);
    }
    public function pay(): void {
        $this->response->addHeader('Content-Type: application/json');
        $this->response->addHeader('Cache-Control: no-store');
        $id=(int)($this->session->data['order_id'] ?? 0); $locked=false;
        try {
            if (($this->request->server['REQUEST_METHOD'] ?? '') !== 'POST' || !$id || empty($this->session->data['xpay_owner']) || empty($this->session->data['xpay_csrf']) || !hash_equals($this->session->data['xpay_csrf'],(string)($this->request->server['HTTP_X_XPAY_CSRF'] ?? ''))) throw new \RuntimeException('Your checkout session expired. Please return to checkout.');
            if (!$this->config->get('payment_xpay_status') || $this->config->get('config_maintenance')) throw new \RuntimeException('XPay payments are temporarily unavailable.');
            $raw=file_get_contents('php://input',false,null,0,32769);
            if (strlen($raw)>32768) throw new \RuntimeException('Payment request too large.');
            $input=json_decode($raw,true,32,JSON_THROW_ON_ERROR);
            if (!is_array($input)) throw new \RuntimeException('Invalid payment request.');
            $locked=(int)$this->db->query("SELECT GET_LOCK('xpay_".DB_PREFIX.$id."', 0) AS ok")->row['ok'] === 1;
            if (!$locked) throw new \RuntimeException('A payment is already being checked. Please recheck shortly.');
            $this->load->model('checkout/order');
            $order=$this->model_checkout_order->getOrder($id);
            if (!$order || (int)$order['store_id'] !== (int)$this->config->get('config_store_id')) throw new \RuntimeException('Order not found.');
            $record=$this->db->query("SELECT * FROM `".DB_PREFIX."xpay_payment` WHERE order_id=".$id)->row;
            $owner=hash('sha256',$this->session->data['xpay_owner']);
            if ($record && !hash_equals($record['owner'],$owner)) throw new \RuntimeException('This payment belongs to another checkout session. Contact the merchant.');
            if ($record && $record['state']==='paid') { $this->json(['paid'=>true]); return; }
            $key=(string)$this->config->get('config_encryption');
            $data=$record ? Security::open($record['data'],$key) : [];
            $action=$input['action'] ?? 'quote';
            if ($record && in_array($record['state'],['submitted','settled'],true)) {
                // Never replace a submitted nonce or request a second signature.
                $this->settle($id,$record,$data,$order,$key); return;
            }
            $snapshot=$this->preflight($order);
            if (!$record || $data['quote']['expires'] <= time() || $data['snapshot'] !== $snapshot) {
                if ($action !== 'quote') throw new \RuntimeException('Order changed or quote expired. Reload checkout before signing.');
                $data=['quote'=>Rules::quote($snapshot['total'],$snapshot['recipient'],time()),'snapshot'=>$snapshot,'sandbox'=>$snapshot['sandbox']];
                $sealed=Security::seal($data,$key);
                // Read back authenticated ciphertext before any signature is requested.
                $this->db->query("INSERT INTO `".DB_PREFIX."xpay_payment` SET order_id=".$id.", owner='".$owner."', state='quote', data='".$this->db->escape($sealed)."', date_modified=NOW() ON DUPLICATE KEY UPDATE state='quote', data=VALUES(data), date_modified=NOW()");
                $saved=$this->db->query("SELECT data FROM `".DB_PREFIX."xpay_payment` WHERE order_id=".$id)->row['data'];
                if (Security::open($saved,$key)!==$data) throw new \RuntimeException('Unable to save payment details.');
            }
            if ($action==='quote') {
                $this->json(['x402Version'=>2,'accepts'=>[$data['quote']['terms']],'nonce'=>$data['quote']['nonce'],'expires'=>$data['quote']['expires'],'sandbox'=>$data['sandbox']]); return;
            }
            if ($action!=='pay') throw new \RuntimeException('No submitted payment to recheck.');
            if ($data['snapshot']!==$snapshot) throw new \RuntimeException('Order changed. Reload checkout.');
            if ($data['sandbox']) {
                if (($input['simulate'] ?? false)!==true) throw new \RuntimeException('Simulation only.');
                // No order is marked paid or released in simulation mode.
                $this->json(['simulated'=>true,'message'=>'Simulation successful. No tokens moved and the order is not marked paid.']); return;
            }
            $payload=$input['paymentPayload'] ?? [];
            Rules::validate($payload,$data['quote'],time());
            $body=['x402Version'=>2,'paymentPayload'=>$payload,'paymentRequirements'=>$data['quote']['terms']];
            $verified=$this->gateway('verify',$body,$id);
            if (($verified['isValid'] ?? null)!==true) throw new \RuntimeException('The payment service rejected this authorization.');
            $data['payload']=$payload;
            $this->save($id,'submitted',$data,$key);
            $record=['state'=>'submitted','tx'=>null];
            $this->settle($id,$record,$data,$order,$key);
        } catch (\Throwable $e) {
            // Never expose keys, URLs containing credentials, stack traces or customer data.
            $message=$e instanceof \RuntimeException ? $e->getMessage() : 'Unable to confirm payment. Recheck the payment or contact the merchant; do not sign again.';
            $this->json(['error'=>$message]);
        } finally {
            if ($locked) $this->db->query("SELECT RELEASE_LOCK('xpay_".DB_PREFIX.$id."')");
        }
    }
    private function preflight(array $order): array {
        if (($this->session->data['payment_method']['code'] ?? '')!=='xpay.xpay' || ($order['payment_method']['code'] ?? '')!=='xpay.xpay' || (int)$order['order_status_id']!==0) throw new \RuntimeException('Order is no longer awaiting XPay payment.');
        if ($this->config->get('config_currency')!=='USD' || $order['currency_code']!=='USD' || (float)$order['currency_value']!==1.0 || ($this->session->data['currency'] ?? '')!=='USD') throw new \RuntimeException('This release accepts USD checkout totals only.');
        if (!$this->cart->hasProducts() || $this->cart->hasSubscription() || !$this->cart->hasStock() || !$this->cart->hasMinimum()) throw new \RuntimeException('The cart is empty or a product is unavailable. Return to checkout.');
        if ((int)$order['customer_id']!==(int)($this->session->data['customer']['customer_id'] ?? -1) || $order['email']!==($this->session->data['customer']['email'] ?? '')) throw new \RuntimeException('Checkout customer changed.');
        if ($this->cart->hasShipping() && (empty($this->session->data['shipping_method']) || empty($this->session->data['shipping_address']))) throw new \RuntimeException('Shipping details are missing.');
        if ($this->config->get('config_checkout_id') && empty($this->session->data['agree'])) throw new \RuntimeException('Accept the checkout terms first.');
        $this->load->model('checkout/cart'); $totals=[]; $taxes=$this->cart->getTaxes(); $total=0;
        ($this->model_checkout_cart->getTotals)($totals,$taxes,$total);
        $amount=number_format((float)$order['total'],2,'.','');
        if (number_format($total,2,'.','')!==$amount) throw new \RuntimeException('Cart total changed. Reload checkout.');
        $normal = static function(array $p, array $options): array {
            $opts=[];
            foreach($options as $o) $opts[]=[(int)$o['product_option_id'],(int)$o['product_option_value_id'],(string)$o['value']];
            sort($opts);
            return [(int)$p['product_id'],(int)$p['quantity'],number_format((float)$p['price'],4,'.',''),$opts];
        };
        $cart=[]; foreach($this->cart->getProducts() as $p) $cart[]=$normal($p,$p['option']);
        $lines=[]; foreach($order['products'] as $p) $lines[]=$normal($p,$this->model_checkout_order->getOptions((int)$order['order_id'],(int)$p['order_product_id']));
        sort($cart); sort($lines);
        if ($cart!==$lines) throw new \RuntimeException('Cart contents changed. Reload checkout.');
        foreach(['shipping','payment'] as $kind) {
            $address=$this->session->data[$kind.'_address'] ?? [];
            foreach(['firstname','lastname','company','address_1','address_2','city','postcode','country_id','zone_id'] as $field) {
                if (isset($address[$field]) && (string)$address[$field] !== (string)$order[$kind.'_'.$field]) throw new \RuntimeException('Checkout address changed. Reload checkout.');
            }
        }
        $recipient=(string)$this->config->get('payment_xpay_recipient');
        if (!Security::address($recipient)) throw new \RuntimeException('Merchant recipient is not configured.');
        return json_decode(json_encode(['total'=>$amount,'recipient'=>$recipient,'sandbox'=>(bool)$this->config->get('payment_xpay_sandbox'),'cart'=>$cart,'order_products'=>$order['products'],'totals'=>$order['totals'],'shipping'=>$this->session->data['shipping_method'] ?? [],'shipping_address'=>$this->session->data['shipping_address'] ?? [],'payment_address'=>$this->session->data['payment_address'] ?? [],'coupon'=>$this->session->data['coupon'] ?? '', 'order_fingerprint'=>$this->fingerprint($order)],JSON_THROW_ON_ERROR),true,64,JSON_THROW_ON_ERROR);
    }
    private function settle(int $id, array $record, array $data, array $order, string $key): void {
        if ($data['sandbox']) throw new \RuntimeException('Simulation cannot settle a live payment.');
        $tx=$record['tx'] ?? null;
        if (!$tx) {
            try {
                $out=$this->gateway('settle',['x402Version'=>2,'paymentPayload'=>$data['payload'],'paymentRequirements'=>$data['quote']['terms']],$id);
            } catch (ServiceError $e) {
                $data['last_service_error']=['http'=>$e->httpStatus,'response'=>$e->details()];
                $this->save($id,'submitted',$data,$key);
                // Retain even a failed response's hash for independent receipt review.
                $details=$e->details();
                if (($details['network']??'')==='eip155:8453' && preg_match('/^0x[a-fA-F0-9]{64}$/D',$details['transaction']??'')) $this->save($id,'settled',$data,$key,strtolower($details['transaction']));
                throw $e;
            }
            if (($out['network'] ?? '')!=='eip155:8453' || !preg_match('/^0x[a-fA-F0-9]{64}$/D',$out['transaction'] ?? '')) { $this->json(['pending'=>true]); return; }
            // A pending response can already identify a broadcast transaction.
            // Persist it and reconcile on chain instead of asking for settlement again.
            if (($out['success'] ?? null)!==true && ($out['status'] ?? '')!=='SETTLEMENT_PENDING') { $this->json(['pending'=>true]); return; }
            $tx=strtolower($out['transaction']);
            $this->save($id,'settled',$data,$key,$tx);
        }
        $chain=$this->rpc('eth_chainId',[]);
        if (($chain['result'] ?? '')!=='0x2105') throw new \RuntimeException('RPC must be connected to Base mainnet.');
        $result=$this->rpc('eth_getTransactionReceipt',[$tx]);
        $receipt=$result['result'] ?? null;
        if (!is_array($receipt)) { $this->json(['pending'=>true]); return; }
        Rules::receipt($receipt,$data['quote'],Rules::payer($data['payload'],'eip155:8453'),$tx);
        // The provider/RPC calls can take time. Re-read the order after them so
        // edits made during settlement cannot pass a stale fingerprint check.
        $order=$this->model_checkout_order->getOrder($id);
        if (!$order) throw new \RuntimeException('Payment received; order unavailable. Contact the merchant for manual review.');
        // Preserve funds proof for manual handling if the order changed after authorization.
        if ($this->fingerprint($order)!==$data['snapshot']['order_fingerprint']) throw new \RuntimeException('Payment received; order changed. Contact the merchant for manual review.');
        $comment='XPay Base USDC verified: '.$tx;
        if ((int)$order['order_status_id']===0) {
            $this->model_checkout_order->addHistory($id,(int)$this->config->get('payment_xpay_order_status_id'),$comment,true);
        } else {
            $history=$this->db->query("SELECT order_history_id FROM `".DB_PREFIX."order_history` WHERE order_id=".$id." AND comment='".$this->db->escape($comment)."' LIMIT 1");
            if (!$history->num_rows) throw new \RuntimeException('Payment received; order status changed. Contact the merchant for manual review.');
        }
        $this->save($id,'paid',$data,$key,$tx);
        $this->json(['paid'=>true]);
    }
    private function fingerprint(array $order): string {
        $keys=['store_id','customer_id','email','total','currency_code','currency_value','payment_method','shipping_method','products','totals'];
        foreach(['payment','shipping'] as $kind) foreach(['firstname','lastname','company','address_1','address_2','city','postcode','country_id','zone_id','custom_field'] as $field) $keys[]=$kind.'_'.$field;
        $fields=[]; foreach($keys as $k) $fields[$k]=$order[$k] ?? null;
        $options=[]; foreach($order['products'] as $p) $options[]=$this->model_checkout_order->getOptions((int)$order['order_id'],(int)$p['order_product_id']);
        $fields['options']=$options;
        return hash('sha256',json_encode($fields,JSON_THROW_ON_ERROR));
    }
    protected function rpc(string $method, array $params): array {
        return Security::post((string)$this->config->get('payment_xpay_rpc'),['jsonrpc'=>'2.0','id'=>1,'method'=>$method,'params'=>$params]);
    }
    protected function gateway(string $path, array $body, int $id): array {
        $key=(string)$this->config->get('payment_xpay_api_key');
        if (strlen($key)<8 || preg_match('/[\r\n]/',$key)) throw new \RuntimeException('Merchant API key is missing.');
        return Security::post(rtrim((string)$this->config->get('payment_xpay_facilitator'),'/').'/'.$path,$body,['Authorization: Bearer '.$key,'Idempotency-Key: opencart-'.hash('sha256',HTTP_SERVER.'|'.$id.'|'.$body['paymentPayload']['payload']['authorization']['nonce'])]);
    }
    private function save(int $id,string $state,array $data,string $key,?string $tx=null): void {
        $this->db->query("UPDATE `".DB_PREFIX."xpay_payment` SET state='".$this->db->escape($state)."',data='".$this->db->escape(Security::seal($data,$key))."', date_modified=NOW()".($tx ? ",tx='".$this->db->escape($tx)."'" : '')." WHERE order_id=".$id);
    }
    private function json(array $data): void { $this->response->setOutput(json_encode($data,JSON_THROW_ON_ERROR)); }
}
