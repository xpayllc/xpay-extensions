<?php
namespace Opencart\System\Library\Extension\Xpay;

/** Preserve provider references without exposing credentials or signed payloads. */
final class ServiceError extends \RuntimeException {
    public int $httpStatus;
    private array $details;
    public function __construct(int $status, array $details=[]) {
        $this->httpStatus=$status;
        $this->details=$details;
        $error=is_array($details['error']??null)?$details['error']:[];
        $rawCode=$error['code']??$details['status']??'';
        $code=is_string($rawCode)||is_int($rawCode)?(string)$rawCode:'';
        $ref=is_string($error['requestId']??null)?$error['requestId']:'';
        $code=preg_match('/^[A-Za-z0-9_-]{1,64}$/D',$code)?$code:'';
        $ref=preg_match('/^[A-Za-z0-9_-]{1,100}$/D',$ref)?$ref:'';
        $message=$status ? 'The payment service could not complete the request (HTTP '.$status.($code?', '.$code:'').').' : 'The payment service connection was interrupted.';
        if ($ref) $message.=' Reference: '.$ref.'.';
        parent::__construct($message.' Check payment status before paying again.');
    }
    /** Raw service error is retained only inside the encrypted server record. */
    public function details(): array { return $this->details; }
}
