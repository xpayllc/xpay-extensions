<?php

namespace Opencart\System\Library\Extension\Xpay;

use RuntimeException;

final class Networks
{
    const BASE = 'eip155:8453';

    const BNB = 'eip155:56';

    const PERMIT2 = '0x000000000022D473030F116dDEE9F6B43aC78BA3';

    const PROXY = '0x402085c248EeA27D92E8b30b2C58ed07f9E20001';

    /**
     * Read the requested network or channel-specific payment setting.
     */
    public static function get(string $network): array
    {
        return match ($network) {
            self::BASE => ['id' => 'base', 'method' => 'xpay', 'chainId' => 8453, 'hexChainId' => '0x2105', 'decimals' => 6, 'asset' => '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', 'extra' => ['name' => 'USD Coin', 'version' => '2'], 'timeout' => 600],
            self::BNB => ['id' => 'bnb', 'method' => 'xpay_bnb', 'chainId' => 56, 'hexChainId' => '0x38', 'decimals' => 18, 'asset' => '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', 'extra' => ['assetTransferMethod' => 'permit2'], 'timeout' => 300],
            default => throw new RuntimeException('Unsupported payment network.'),
        };
    }
}
