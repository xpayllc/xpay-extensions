<?php

namespace Opencart\System\Library\Extension\Xpay;

use RuntimeException;

final class Rules
{
    const NETWORK = Networks::BASE;

    const ASSET = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913';

    const TRANSFER = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef';

    const AUTH_USED = '0x98de503528ee59b575ef0c0a2576a82497bfc029a5685b209e9ec333479b10a5';

    /**
     * Convert a decimal amount into exact atomic token units.
     */
    public static function amount(string $total, int $decimals = 6): string
    {
        if (
            PHP_INT_SIZE < 8
            || ! in_array($decimals, [6, 18], true)
        ) {
            throw new RuntimeException('Invalid or mismatched payment authorization.');
        }
        if (! preg_match('/^([0-9]{1,10})(?:\.([0-9]{1,'.$decimals.'}))?$/D', $total, $m)) {
            throw new RuntimeException('Invalid or mismatched payment authorization.');
        }
        $n = ltrim($m[1].str_pad($m[2] ?? '', $decimals, '0'), '0');
        if ($n === '') {
            throw new RuntimeException('Invalid or mismatched payment authorization.');
        }

        return $n;
    }

    /**
     * Encode an unsigned decimal integer as an EVM word.
     */
    public static function hex(string $n): string
    {
        if (! preg_match('/^(0|[1-9][0-9]{0,77})$/D', $n)) {
            throw new RuntimeException('Invalid or mismatched payment authorization.');
        }
        $out = '';
        do {
            $q = '';
            $carry = 0;
            foreach (str_split($n) as $digit) {
                $v = $carry * 10 + (int) $digit;
                $q .= (string) intdiv($v, 16);
                $carry = $v % 16;
            }$out = dechex($carry).$out;
            $n = ltrim($q, '0') ?: '0';
        } while ($n !== '0');
        if (strlen($out) > 64) {
            throw new RuntimeException('Invalid or mismatched payment authorization.');
        }

        return $out;
    }

    /**
     * Decode an EVM hexadecimal integer without floating-point arithmetic.
     */
    public static function decimal(string $hex): string
    {
        if (! preg_match('/^[0-9a-f]{1,64}$/iD', $hex)) {
            throw new RuntimeException('Invalid or mismatched payment authorization.');
        }
        $out = '0';
        foreach (str_split(strtolower($hex)) as $h) {
            $carry = hexdec($h);
            $next = '';
            for ($i = strlen($out) - 1; $i >= 0; $i--) {
                $v = (int) $out[$i] * 16 + $carry;
                $next = (string) ($v % 10).$next;
                $carry = intdiv($v, 10);
            }while ($carry) {
                $next = (string) ($carry % 10).$next;
                $carry = intdiv($carry, 10);
            }$out = ltrim($next, '0') ?: '0';
        }

        return $out;
    }

    /**
     * Create short-lived, order-bound payment requirements.
     */
    public static function quote(string $total, string $recipient, int $now, string $network = Networks::BASE): array
    {
        $n = Networks::get($network);
        if (! preg_match('/^0x[a-fA-F0-9]{40}$/D', $recipient)) {
            throw new RuntimeException('Invalid or mismatched payment authorization.');
        }
        $random = bin2hex(random_bytes(32));

        return ['nonce' => $network === Networks::BNB ? self::decimal($random) : '0x'.$random, 'expires' => $now + $n['timeout'], 'terms' => ['scheme' => 'exact', 'network' => $network, 'amount' => self::amount($total, $n['decimals']), 'asset' => $n['asset'], 'payTo' => $recipient, 'maxTimeoutSeconds' => $n['timeout'], 'extra' => $n['extra']]];
    }

    /**
     * Read the payer from the supported authorization format.
     */
    public static function payer(array $p, string $network): string
    {
        return $network === Networks::BNB ? ($p['payload']['permit2Authorization']['from'] ?? '') : ($p['payload']['authorization']['from'] ?? '');
    }

    /**
     * Validate the configured payment or authorization before it can be used.
     */
    public static function validate(array $p, array $q, int $now): void
    {
        $n = Networks::get($q['terms']['network']);
        $payer = self::payer($p, $q['terms']['network']);
        if (
            ($p['x402Version'] ?? null) !== 2
            || ($p['accepted'] ?? null) != $q['terms']
            || $now >= $q['expires']
            || ! preg_match('/^0x[a-fA-F0-9]{40}$/D', $payer)
            || ! preg_match('/^0x[a-fA-F0-9]{130}$/D', $p['payload']['signature'] ?? '')
        ) {
            throw new RuntimeException('Invalid or mismatched payment authorization.');
        }
        if ($q['terms']['network'] === Networks::BNB) {
            $a = $p['payload']['permit2Authorization'] ?? [];
            if (
                ($a['nonce'] ?? null) !== $q['nonce']
                || ($a['permitted']['amount'] ?? null) !== $q['terms']['amount']
                || strtolower($a['permitted']['token'] ?? '') !== strtolower($n['asset'])
                || strtolower($a['spender'] ?? '') !== strtolower(Networks::PROXY)
                || strtolower($a['witness']['to'] ?? '') !== strtolower($q['terms']['payTo'])
                || ! ctype_digit((string) ($a['deadline'] ?? ''))
                || (int) $a['deadline'] > $q['expires']
                || (int) $a['deadline'] <= $now + 5
                || ! ctype_digit((string) ($a['witness']['validAfter'] ?? ''))
                || (int) $a['witness']['validAfter'] > $now
            ) {
                throw new RuntimeException('Invalid or mismatched payment authorization.');
            }
        } else {
            $a = $p['payload']['authorization'] ?? [];
            if (
                ($a['nonce'] ?? '') !== $q['nonce']
                || (string) ($a['value'] ?? '') !== $q['terms']['amount']
                || strtolower($a['to'] ?? '') !== strtolower($q['terms']['payTo'])
                || ! ctype_digit((string) ($a['validBefore'] ?? ''))
                || (int) $a['validBefore'] > $q['expires']
                || (int) $a['validBefore'] <= $now
                || ! ctype_digit((string) ($a['validAfter'] ?? ''))
                || (int) $a['validAfter'] >= $now
            ) {
                throw new RuntimeException('Invalid or mismatched payment authorization.');
            }
        }
    }

    /**
     * Encode the exact Permit2 settlement call bound to the authorization.
     */
    public static function permit2Calldata(array $p): string
    {
        $a = $p['payload']['permit2Authorization'];
        $sig = substr($p['payload']['signature'], 2);
        if (! preg_match('/^[a-fA-F0-9]{130}$/D', $sig)) {
            throw new RuntimeException('Invalid or mismatched payment authorization.');
        }
        $address = fn ($v) => str_pad(strtolower(substr($v, 2)), 64, '0', STR_PAD_LEFT);
        $word = fn ($v) => str_pad(self::hex((string) $v), 64, '0', STR_PAD_LEFT);

        return '0x13cd3b53'.$address($a['permitted']['token']).$word($a['permitted']['amount']).$word($a['nonce']).$word($a['deadline']).$address($a['from']).$address($a['witness']['to']).$word($a['witness']['validAfter']).$word('256').$word('65').str_pad(strtolower($sig), 192, '0');
    }

    /**
     * Verify successful settlement against the expected token, payer, amount and nonce.
     */
    public static function receipt(array $receipt, array $q, string $payer, string $tx, ?array $transaction = null, ?array $payload = null): void
    {
        $n = Networks::get($q['terms']['network']);
        if (
            ($receipt['status'] ?? '') !== '0x1'
            || strtolower($receipt['transactionHash'] ?? '') !== strtolower($tx)
        ) {
            throw new RuntimeException('Invalid or mismatched payment authorization.');
        }
        $transfer = false;
        $nonce = false;
        foreach ($receipt['logs'] ?? [] as $l) {
            if (
                ! empty($l['removed'])
                || strtolower($l['address'] ?? '') !== strtolower($n['asset'])
            ) {
                continue;
            }
            $t = $l['topics'] ?? [];
            if (
                count($t) === 3
                && strtolower($t[0]) === self::TRANSFER
                && strtolower(substr($t[1], -40)) === strtolower(substr($payer, 2))
                && strtolower(substr($t[2], -40)) === strtolower(substr($q['terms']['payTo'], 2))
                && strtolower($l['data'] ?? '') === '0x'.str_pad(self::hex($q['terms']['amount']), 64, '0', STR_PAD_LEFT)
            ) {
                $transfer = true;
            }
            if (
                $q['terms']['network'] === Networks::BASE
                && count($t) === 3
                && strtolower($t[0]) === self::AUTH_USED
                && strtolower(substr($t[1], -40)) === strtolower(substr($payer, 2))
                && strtolower($t[2]) === strtolower($q['nonce'])
            ) {
                $nonce = true;
            }
        }
        if ($q['terms']['network'] === Networks::BNB) {
            $nonce = $transaction && $payload && strtolower($transaction['hash'] ?? '') === strtolower($tx) && strtolower($transaction['to'] ?? '') === strtolower(Networks::PROXY) && in_array($transaction['value'] ?? null, ['0x0', '0x00'], true) && strtolower($transaction['input'] ?? '') === self::permit2Calldata($payload);
        }
        if (
            ! $transfer
            || ! $nonce
        ) {
            throw new RuntimeException('Invalid or mismatched payment authorization.');
        }
    }
}
