<?php
namespace Opencart\System\Library\Extension\Xpay;

/** Validation, authenticated encryption and bounded requests for payment data. */
final class Security {
    public static function address(string $s): bool {
        return (bool)preg_match('/^0x[0-9a-fA-F]{40}$/D', $s) && strtolower($s) !== '0x'.str_repeat('0', 40);
    }
    public static function url(string $s): bool {
        $u = parse_url($s);
        if (!$u || ($u['scheme'] ?? '') !== 'https' || empty($u['host']) || isset($u['user']) || isset($u['pass']) || isset($u['fragment']) || (isset($u['port']) && $u['port'] !== 443)) return false;
        if (filter_var($u['host'], FILTER_VALIDATE_IP) || !str_contains($u['host'], '.') || preg_match('/\.(local|internal|localhost)$/i', $u['host'])) return false;
        return (bool)filter_var($s, FILTER_VALIDATE_URL);
    }
    public static function seal(array $data, string $key): string {
        if (strlen($key) < 16) throw new \RuntimeException('Configure the OpenCart encryption key.');
        $iv = random_bytes(12); $tag = '';
        $ct = openssl_encrypt(json_encode($data, JSON_THROW_ON_ERROR), 'aes-256-gcm', hash('sha256', $key, true), OPENSSL_RAW_DATA, $iv, $tag);
        if ($ct === false) throw new \RuntimeException('Unable to secure payment data.');
        return base64_encode($iv.$tag.$ct);
    }
    public static function open(string $encoded, string $key): array {
        $raw = base64_decode($encoded, true);
        if ($raw === false || strlen($raw) < 29) throw new \RuntimeException('Payment data is damaged.');
        $plain = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', hash('sha256', $key, true), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
        if ($plain === false) throw new \RuntimeException('Payment data authentication failed.');
        return json_decode($plain, true, 64, JSON_THROW_ON_ERROR);
    }
    public static function post(string $url, array $body, array $headers = []): array {
        if (!self::url($url)) throw new \RuntimeException('Invalid payment service URL.');
        $host = parse_url($url, PHP_URL_HOST);
        $ips = gethostbynamel($host) ?: [];
        if (!$ips) throw new \RuntimeException('Payment service is unavailable.');
        foreach ($ips as $ip) if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) throw new \RuntimeException('Payment service address is not public.');
        $ch = curl_init($url); $response = '';
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($body, JSON_THROW_ON_ERROR), CURLOPT_HTTPHEADER => array_merge(['Content-Type: application/json', 'Accept: application/json'], $headers), CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_TIMEOUT => 25, CURLOPT_FOLLOWLOCATION => false, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2, CURLOPT_RESOLVE => [$host.':443:'.$ips[0]], CURLOPT_WRITEFUNCTION => static function($ch, $chunk) use (&$response) { if (strlen($response) + strlen($chunk) > 1048576) return 0; $response .= $chunk; return strlen($chunk); }]);
        $ok = curl_exec($ch); $status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE); curl_close($ch);
        return self::decode($response, $status, $ok !== false);
    }
    public static function decode(string $response, int $status, bool $transportOk=true): array {
        $out=json_decode($response,true,64);
        if (!$transportOk || $status < 200 || $status >= 300) throw new ServiceError($transportOk?$status:0,is_array($out)?$out:[]);
        if (!is_array($out) || json_last_error()!==JSON_ERROR_NONE) throw new \RuntimeException('The payment service returned an unreadable response. Check payment status before paying again.');
        return $out;
    }
}
